﻿namespace SampleApp
{
	partial class OnlookerDetectedForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.onlookerSnoozeComboBox = new System.Windows.Forms.ComboBox();
			this.odSnoozeButton = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// onlookerSnoozeComboBox
			// 
			this.onlookerSnoozeComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.onlookerSnoozeComboBox.FormattingEnabled = true;
			this.onlookerSnoozeComboBox.Location = new System.Drawing.Point(41, 22);
			this.onlookerSnoozeComboBox.Name = "onlookerSnoozeComboBox";
			this.onlookerSnoozeComboBox.Size = new System.Drawing.Size(153, 21);
			this.onlookerSnoozeComboBox.TabIndex = 0;
			this.onlookerSnoozeComboBox.Text = "Select Snooze Time";
			this.onlookerSnoozeComboBox.SelectedIndexChanged += new System.EventHandler(this.onlookerSnoozeComboBox_SelectedIndexChanged);
			// 
			// odSnoozeButton
			// 
			this.odSnoozeButton.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.odSnoozeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.odSnoozeButton.Location = new System.Drawing.Point(64, 59);
			this.odSnoozeButton.Name = "odSnoozeButton";
			this.odSnoozeButton.Size = new System.Drawing.Size(101, 24);
			this.odSnoozeButton.TabIndex = 2;
			this.odSnoozeButton.Text = "Snooze";
			this.odSnoozeButton.UseVisualStyleBackColor = true;
			// 
			// OnlookerDetectedForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(230, 95);
			this.Controls.Add(this.odSnoozeButton);
			this.Controls.Add(this.onlookerSnoozeComboBox);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "OnlookerDetectedForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Onlooker Detected";
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.ComboBox onlookerSnoozeComboBox;
		private System.Windows.Forms.Button odSnoozeButton;
	}
}