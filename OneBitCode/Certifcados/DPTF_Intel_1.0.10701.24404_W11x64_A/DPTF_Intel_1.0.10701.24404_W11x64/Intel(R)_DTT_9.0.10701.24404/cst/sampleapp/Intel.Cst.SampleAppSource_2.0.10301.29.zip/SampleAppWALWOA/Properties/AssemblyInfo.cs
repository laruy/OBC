﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("SampleApp")]
[assembly: AssemblyDescription("Intel (R) Context Sensing Sample App")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Intel")]
[assembly: AssemblyProduct("SampleApp")]
[assembly: AssemblyCopyright("Copyright © Intel Corporation 2021")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("5f048cae-e0ec-4ca9-89c5-c8395b25b39c")]

// log4net setting
[assembly: log4net.Config.XmlConfigurator(ConfigFile = "log4net.config", Watch = true)]
