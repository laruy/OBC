﻿namespace SampleApp
{
	partial class FormWALWOA
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormWALWOA));
			this.walLabel = new System.Windows.Forms.Label();
			this.woaLabel = new System.Windows.Forms.Label();
			this.woaCheckBox = new System.Windows.Forms.CheckBox();
			this.walCheckBox = new System.Windows.Forms.CheckBox();
			this.preDimIntervalLabel = new System.Windows.Forms.Label();
			this.preDimIntervalComboBox = new System.Windows.Forms.ComboBox();
			this.panelWoa = new System.Windows.Forms.Panel();
			this.woaBatteryRemainingComboBox = new System.Windows.Forms.ComboBox();
			this.woaBatteryRemainingLabel = new System.Windows.Forms.Label();
			this.panel6 = new System.Windows.Forms.Panel();
			this.woaEnableOnBatteryFalseRadioButton = new System.Windows.Forms.RadioButton();
			this.woaEnableOnBatteryTrueRadioButton = new System.Windows.Forms.RadioButton();
			this.woaEnableOnBatteryLabel = new System.Windows.Forms.Label();
			this.panel5 = new System.Windows.Forms.Panel();
			this.woaExternalMonitorOffRadioButton = new System.Windows.Forms.RadioButton();
			this.woaExternalMonitorOnRadioButton = new System.Windows.Forms.RadioButton();
			this.woaExternalMonitorLabel = new System.Windows.Forms.Label();
			this.notPresentDimTargetLabel = new System.Windows.Forms.Label();
			this.notPresentDimTargetComboBox = new System.Windows.Forms.ComboBox();
			this.lockAfterDimIntervalLabel = new System.Windows.Forms.Label();
			this.lockAfterDimIntervalComboBox = new System.Windows.Forms.ComboBox();
			this.userPresentWaitIntervalLabel = new System.Windows.Forms.Label();
			this.userPresentWaitIntervalComboBox = new System.Windows.Forms.ComboBox();
			this.walPanel = new System.Windows.Forms.Panel();
			this.woaPanel = new System.Windows.Forms.Panel();
			this.proximityDistanceValueLabel = new System.Windows.Forms.Label();
			this.proximityDistancePanel = new System.Windows.Forms.Panel();
			this.proximityDistanceLabel = new System.Windows.Forms.Label();
			this.lineSeparator = new System.Windows.Forms.Label();
			this.comboBoxWaitTimer = new System.Windows.Forms.ComboBox();
			this.nlopWaitTimerLabel = new System.Windows.Forms.Label();
			this.panelNlop = new System.Windows.Forms.Panel();
			this.panel8 = new System.Windows.Forms.Panel();
			this.nlopEnableOnBatteryFalseRadioButton = new System.Windows.Forms.RadioButton();
			this.nlopEnableOnBatteryTrueRadioButton = new System.Windows.Forms.RadioButton();
			this.nlopEnableOnBatteryLabel = new System.Windows.Forms.Label();
			this.nlopFailSafeTimerLabel = new System.Windows.Forms.Label();
			this.panel7 = new System.Windows.Forms.Panel();
			this.nlopExternalMonitorOffRadioButton = new System.Windows.Forms.RadioButton();
			this.nlopExternalMonitorOnRadioButton = new System.Windows.Forms.RadioButton();
			this.nlopExternalMonitorLabel = new System.Windows.Forms.Label();
			this.nlopFailSafeTimeoutComboBox = new System.Windows.Forms.ComboBox();
			this.nlopBatteryRemainingComboBox = new System.Windows.Forms.ComboBox();
			this.nlopBatteryRemainingLabel = new System.Windows.Forms.Label();
			this.groupBoxTrigger = new System.Windows.Forms.GroupBox();
			this.buttonTiggerStop = new System.Windows.Forms.Button();
			this.buttonTriggerStart = new System.Windows.Forms.Button();
			this.nlopPanel = new System.Windows.Forms.Panel();
			this.nlopCheckBox = new System.Windows.Forms.CheckBox();
			this.nlopLabel = new System.Windows.Forms.Label();
			this.panelWal = new System.Windows.Forms.Panel();
			this.notPresentDimmingTimeLabel = new System.Windows.Forms.Label();
			this.notPresentDimmingTimeComboBox = new System.Windows.Forms.ComboBox();
			this.panel4 = new System.Windows.Forms.Panel();
			this.displayOffOnRadioButton = new System.Windows.Forms.RadioButton();
			this.displayOffOffRadioButton = new System.Windows.Forms.RadioButton();
			this.displayOffAfterLockLabel = new System.Windows.Forms.Label();
			this.panel3 = new System.Windows.Forms.Panel();
			this.honorUserInCallOnRadioButton = new System.Windows.Forms.RadioButton();
			this.honorUserInCallOffRadioButton = new System.Windows.Forms.RadioButton();
			this.honorUserInCallLabel = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.honorPowerRequestsOnRadioButton = new System.Windows.Forms.RadioButton();
			this.honorPowerRequestsOffRadioButton = new System.Windows.Forms.RadioButton();
			this.honorPowerRequestsLabel = new System.Windows.Forms.Label();
			this.dimScreenPanel = new System.Windows.Forms.Panel();
			this.dimScreenOnRadioButton = new System.Windows.Forms.RadioButton();
			this.dimScreenOffRadioButton = new System.Windows.Forms.RadioButton();
			this.dimScreenLabel = new System.Windows.Forms.Label();
			this.walExternalMonitorPanel = new System.Windows.Forms.Panel();
			this.walExternalMonitorLabel = new System.Windows.Forms.Label();
			this.walExternalMonitorOnRadioButton = new System.Windows.Forms.RadioButton();
			this.walExternalMonitorOffRadioButton = new System.Windows.Forms.RadioButton();
			this.adPanel = new System.Windows.Forms.Panel();
			this.adCheckBox = new System.Windows.Forms.CheckBox();
			this.adLabel = new System.Windows.Forms.Label();
			this.panelAd = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.honorUserInCallADRadioButtonOn = new System.Windows.Forms.RadioButton();
			this.honorUserInCallADRadioButtonOff = new System.Windows.Forms.RadioButton();
			this.label2 = new System.Windows.Forms.Label();
			this.panel9 = new System.Windows.Forms.Panel();
			this.adHonorPowerRequestOffRadioButton = new System.Windows.Forms.RadioButton();
			this.adHonorPowerRequestOnRadioButton = new System.Windows.Forms.RadioButton();
			this.label1 = new System.Windows.Forms.Label();
			this.dimWaitDisengagedAdLabel = new System.Windows.Forms.Label();
			this.adDisengagedDimWaitTimeComboBox = new System.Windows.Forms.ComboBox();
			this.MP4DimWaitComboBox = new System.Windows.Forms.ComboBox();
			this.MP4DimWaitLabel = new System.Windows.Forms.Label();
			this.MP3DimWaitComboBox = new System.Windows.Forms.ComboBox();
			this.MP3DimWaitLabel = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.adExternalMonitorOffRadioButton = new System.Windows.Forms.RadioButton();
			this.adExternalMonitorOnRadioButton = new System.Windows.Forms.RadioButton();
			this.adExternalMonitorLabel = new System.Windows.Forms.Label();
			this.dimTargetLabel = new System.Windows.Forms.Label();
			this.adDimTargetComboBox = new System.Windows.Forms.ComboBox();
			this.dimmingIntervalLabel = new System.Windows.Forms.Label();
			this.adDimmingIntervalComboBox = new System.Windows.Forms.ComboBox();
			this.MP2DimWaitComboBox = new System.Windows.Forms.ComboBox();
			this.MP2DimWaitLabel = new System.Windows.Forms.Label();
			this.MP1DimWaitComboBox = new System.Windows.Forms.ComboBox();
			this.MP1DimWaitLabel = new System.Windows.Forms.Label();
			this.dimWaitNotPresentAdLabel = new System.Windows.Forms.Label();
			this.adNotPresentDimWaitTimeComboBox = new System.Windows.Forms.ComboBox();
			this.mispredictionTimeLabel = new System.Windows.Forms.Label();
			this.mispredictionTimeWindowCombobox = new System.Windows.Forms.ComboBox();
			this.mispredictionWithFaceDetectionCheckbox = new System.Windows.Forms.CheckBox();
			this.mispredictionFaceDetectionLabel = new System.Windows.Forms.Label();
			this.globalModeCheckbox = new System.Windows.Forms.CheckBox();
			this.globalModeLabel = new System.Windows.Forms.Label();
			this.globalModePanel = new System.Windows.Forms.Panel();
			this.testModeCheckbox = new System.Windows.Forms.CheckBox();
			this.testModeLabel = new System.Windows.Forms.Label();
			this.presenceStatusPanel = new System.Windows.Forms.Panel();
			this.SensorUserPresenceValueLabel = new System.Windows.Forms.Label();
			this.PolicyUserPresenceValueLabel = new System.Windows.Forms.Label();
			this.PlatformUserPresenceValueLabel = new System.Windows.Forms.Label();
			this.SensorUserPresenceStatusLabel = new System.Windows.Forms.Label();
			this.PolicyUserPresenceStatusLabel = new System.Windows.Forms.Label();
			this.PlatformUserPresenceStatusLabel = new System.Windows.Forms.Label();
			this.privacyPanel = new System.Windows.Forms.Panel();
			this.privacyCheckbox = new System.Windows.Forms.CheckBox();
			this.privacyLabel = new System.Windows.Forms.Label();
			this.appFeaturesPanel = new System.Windows.Forms.Panel();
			this.enabledEventsLabel = new System.Windows.Forms.Label();
			this.enabledEventsListBox = new System.Windows.Forms.ListBox();
			this.monitorAppCheckbox = new System.Windows.Forms.CheckBox();
			this.monitorAppLabel = new System.Windows.Forms.Label();
			this.appNameComboBox = new System.Windows.Forms.ComboBox();
			this.appNameLabel = new System.Windows.Forms.Label();
			this.onlookerDetectionPanel = new System.Windows.Forms.Panel();
			this.onlookerDetectionCheckBox = new System.Windows.Forms.CheckBox();
			this.onlookerDetectionLabel = new System.Windows.Forms.Label();
			this.onlookerDetectionSettingsPanel = new System.Windows.Forms.Panel();
			this.odCancelSnoozeButton = new System.Windows.Forms.Button();
			this.onlookerDetectionEnableOnLowBatteryPanel = new System.Windows.Forms.Panel();
			this.onlookerDetectionEnableOnLowBatteryOffRadioButton = new System.Windows.Forms.RadioButton();
			this.onlookerDetectionEnableOnLowBatteryOnRadioButton = new System.Windows.Forms.RadioButton();
			this.onlookerDetectionEnableOnLowBatteryLabel = new System.Windows.Forms.Label();
			this.onlookerDetectionDimWhenOnlookerDetectedPanel = new System.Windows.Forms.Panel();
			this.onlookerDetectionDimWhenDetectedOffRadioButton = new System.Windows.Forms.RadioButton();
			this.onlookerDetectionDimWhenDetectedOnRadioButton = new System.Windows.Forms.RadioButton();
			this.onlookerDetectionDimWhenDetectedLabel = new System.Windows.Forms.Label();
			this.onlookerDetectionAbsenceIntervalComboBox = new System.Windows.Forms.ComboBox();
			this.onlookerDetectionAbsenceWaitTimeLabel = new System.Windows.Forms.Label();
			this.onlookerDetectionEnableWithExternalMonitorPanel = new System.Windows.Forms.Panel();
			this.onlookerDetectionExternalMonitorOffRadioButton = new System.Windows.Forms.RadioButton();
			this.onlookerDetectionExternalMonitorOnRadioButton = new System.Windows.Forms.RadioButton();
			this.onlookerDetectionExternalMonitorLabel = new System.Windows.Forms.Label();
			this.onlookerDetectionDimTargetLabel = new System.Windows.Forms.Label();
			this.onlookerDetectionDimTargetComboBox = new System.Windows.Forms.ComboBox();
			this.onlookerDetectionDimmingTimeLabel = new System.Windows.Forms.Label();
			this.onlookerDetectionDimmingTimeComboBox = new System.Windows.Forms.ComboBox();
			this.onlookerDetectionLowBatteryLimitComboBox = new System.Windows.Forms.ComboBox();
			this.onlookerDetectionLowBatteryLimitLabel = new System.Windows.Forms.Label();
			this.onlookerDetectionDelayIntervalComboBox = new System.Windows.Forms.ComboBox();
			this.onlookerDetectionDelayIntervalLabel = new System.Windows.Forms.Label();
			this.icstSampleAppVersionLabel = new System.Windows.Forms.Label();
			this.extendedCapabilitiesPanel = new System.Windows.Forms.Panel();
			this.panel12 = new System.Windows.Forms.Panel();
			this.biometricPresenceSensorStatusValueLabel = new System.Windows.Forms.Label();
			this.biometricPresenceSensorStatusLabel = new System.Windows.Forms.Label();
			this.panel11 = new System.Windows.Forms.Panel();
			this.correlationStatusValueLabel = new System.Windows.Forms.Label();
			this.correlationStatusLabel = new System.Windows.Forms.Label();
			this.extendedCapabilitiesLabel = new System.Windows.Forms.Label();
			this.odSensorStatusPanel = new System.Windows.Forms.Panel();
			this.odSensorStatusVallabel = new System.Windows.Forms.Label();
			this.odSensorStatusLabel = new System.Windows.Forms.Label();
			this.activeSensorTypePanel = new System.Windows.Forms.Panel();
			this.activeSensorTypeValLabel = new System.Windows.Forms.Label();
			this.activeSensorTypeLabel = new System.Windows.Forms.Label();
			this.mispredictionCountPanel = new System.Windows.Forms.Panel();
			this.mispredictionCountValLabel = new System.Windows.Forms.Label();
			this.mispredictionCountLabel = new System.Windows.Forms.Label();
			this.appEnabledPanel = new System.Windows.Forms.Panel();
			this.appEnabledCheckBox = new System.Windows.Forms.CheckBox();
			this.panelWoa.SuspendLayout();
			this.panel6.SuspendLayout();
			this.panel5.SuspendLayout();
			this.walPanel.SuspendLayout();
			this.woaPanel.SuspendLayout();
			this.proximityDistancePanel.SuspendLayout();
			this.panelNlop.SuspendLayout();
			this.panel8.SuspendLayout();
			this.panel7.SuspendLayout();
			this.groupBoxTrigger.SuspendLayout();
			this.nlopPanel.SuspendLayout();
			this.panelWal.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panel2.SuspendLayout();
			this.dimScreenPanel.SuspendLayout();
			this.walExternalMonitorPanel.SuspendLayout();
			this.adPanel.SuspendLayout();
			this.panelAd.SuspendLayout();
			this.panel10.SuspendLayout();
			this.panel9.SuspendLayout();
			this.panel1.SuspendLayout();
			this.globalModePanel.SuspendLayout();
			this.presenceStatusPanel.SuspendLayout();
			this.privacyPanel.SuspendLayout();
			this.appFeaturesPanel.SuspendLayout();
			this.onlookerDetectionPanel.SuspendLayout();
			this.onlookerDetectionSettingsPanel.SuspendLayout();
			this.onlookerDetectionEnableOnLowBatteryPanel.SuspendLayout();
			this.onlookerDetectionDimWhenOnlookerDetectedPanel.SuspendLayout();
			this.onlookerDetectionEnableWithExternalMonitorPanel.SuspendLayout();
			this.extendedCapabilitiesPanel.SuspendLayout();
			this.panel12.SuspendLayout();
			this.panel11.SuspendLayout();
			this.odSensorStatusPanel.SuspendLayout();
			this.activeSensorTypePanel.SuspendLayout();
			this.mispredictionCountPanel.SuspendLayout();
			this.appEnabledPanel.SuspendLayout();
			this.SuspendLayout();
			// 
			// walLabel
			// 
			this.walLabel.AutoSize = true;
			this.walLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.walLabel.Location = new System.Drawing.Point(5, 5);
			this.walLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.walLabel.Name = "walLabel";
			this.walLabel.Size = new System.Drawing.Size(106, 14);
			this.walLabel.TabIndex = 7;
			this.walLabel.Text = "Walk Away Lock";
			// 
			// woaLabel
			// 
			this.woaLabel.AutoSize = true;
			this.woaLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.woaLabel.Location = new System.Drawing.Point(2, 3);
			this.woaLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.woaLabel.Name = "woaLabel";
			this.woaLabel.Size = new System.Drawing.Size(124, 14);
			this.woaLabel.TabIndex = 6;
			this.woaLabel.Text = "Wake On Approach";
			// 
			// woaCheckBox
			// 
			this.woaCheckBox.AutoSize = true;
			this.woaCheckBox.Location = new System.Drawing.Point(180, 4);
			this.woaCheckBox.Margin = new System.Windows.Forms.Padding(2);
			this.woaCheckBox.Name = "woaCheckBox";
			this.woaCheckBox.Size = new System.Drawing.Size(15, 14);
			this.woaCheckBox.TabIndex = 5;
			this.woaCheckBox.UseVisualStyleBackColor = true;
			this.woaCheckBox.CheckedChanged += new System.EventHandler(this.checkBoxWOA_CheckedChanged);
			this.woaCheckBox.EnabledChanged += new System.EventHandler(this.checkBoxWOA_EnabledChanged);
			// 
			// walCheckBox
			// 
			this.walCheckBox.AutoSize = true;
			this.walCheckBox.Cursor = System.Windows.Forms.Cursors.Default;
			this.walCheckBox.Location = new System.Drawing.Point(183, 5);
			this.walCheckBox.Margin = new System.Windows.Forms.Padding(2);
			this.walCheckBox.Name = "walCheckBox";
			this.walCheckBox.Size = new System.Drawing.Size(15, 14);
			this.walCheckBox.TabIndex = 4;
			this.walCheckBox.UseVisualStyleBackColor = true;
			this.walCheckBox.CheckedChanged += new System.EventHandler(this.checkBoxWAL_CheckedChanged);
			this.walCheckBox.EnabledChanged += new System.EventHandler(this.checkBoxWAL_EnabledChanged);
			// 
			// preDimIntervalLabel
			// 
			this.preDimIntervalLabel.AutoSize = true;
			this.preDimIntervalLabel.Location = new System.Drawing.Point(3, 31);
			this.preDimIntervalLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.preDimIntervalLabel.Name = "preDimIntervalLabel";
			this.preDimIntervalLabel.Size = new System.Drawing.Size(75, 13);
			this.preDimIntervalLabel.TabIndex = 10;
			this.preDimIntervalLabel.Text = "Time Until Dim";
			// 
			// preDimIntervalComboBox
			// 
			this.preDimIntervalComboBox.AllowDrop = true;
			this.preDimIntervalComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.preDimIntervalComboBox.FormattingEnabled = true;
			this.preDimIntervalComboBox.Location = new System.Drawing.Point(152, 29);
			this.preDimIntervalComboBox.Name = "preDimIntervalComboBox";
			this.preDimIntervalComboBox.Size = new System.Drawing.Size(87, 21);
			this.preDimIntervalComboBox.TabIndex = 20;
			this.preDimIntervalComboBox.SelectedIndexChanged += new System.EventHandler(this.preDimIntervalComboBox_SelectedIndexChanged);
			// 
			// panelWoa
			// 
			this.panelWoa.Controls.Add(this.woaBatteryRemainingComboBox);
			this.panelWoa.Controls.Add(this.woaBatteryRemainingLabel);
			this.panelWoa.Controls.Add(this.panel6);
			this.panelWoa.Controls.Add(this.panel5);
			this.panelWoa.Location = new System.Drawing.Point(266, 36);
			this.panelWoa.Name = "panelWoa";
			this.panelWoa.Size = new System.Drawing.Size(252, 79);
			this.panelWoa.TabIndex = 25;
			// 
			// woaBatteryRemainingComboBox
			// 
			this.woaBatteryRemainingComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.woaBatteryRemainingComboBox.FormattingEnabled = true;
			this.woaBatteryRemainingComboBox.Location = new System.Drawing.Point(167, 55);
			this.woaBatteryRemainingComboBox.Name = "woaBatteryRemainingComboBox";
			this.woaBatteryRemainingComboBox.Size = new System.Drawing.Size(73, 21);
			this.woaBatteryRemainingComboBox.TabIndex = 35;
			this.woaBatteryRemainingComboBox.SelectedIndexChanged += new System.EventHandler(this.woaBatteryComboBox_SelectedIndexChanged);
			// 
			// woaBatteryRemainingLabel
			// 
			this.woaBatteryRemainingLabel.AutoSize = true;
			this.woaBatteryRemainingLabel.Location = new System.Drawing.Point(7, 60);
			this.woaBatteryRemainingLabel.Name = "woaBatteryRemainingLabel";
			this.woaBatteryRemainingLabel.Size = new System.Drawing.Size(87, 13);
			this.woaBatteryRemainingLabel.TabIndex = 34;
			this.woaBatteryRemainingLabel.Text = "Low Battery Limit";
			// 
			// panel6
			// 
			this.panel6.Controls.Add(this.woaEnableOnBatteryFalseRadioButton);
			this.panel6.Controls.Add(this.woaEnableOnBatteryTrueRadioButton);
			this.panel6.Controls.Add(this.woaEnableOnBatteryLabel);
			this.panel6.Location = new System.Drawing.Point(5, 29);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(240, 22);
			this.panel6.TabIndex = 83;
			// 
			// woaEnableOnBatteryFalseRadioButton
			// 
			this.woaEnableOnBatteryFalseRadioButton.AutoSize = true;
			this.woaEnableOnBatteryFalseRadioButton.Location = new System.Drawing.Point(191, 2);
			this.woaEnableOnBatteryFalseRadioButton.Name = "woaEnableOnBatteryFalseRadioButton";
			this.woaEnableOnBatteryFalseRadioButton.Size = new System.Drawing.Size(50, 17);
			this.woaEnableOnBatteryFalseRadioButton.TabIndex = 36;
			this.woaEnableOnBatteryFalseRadioButton.TabStop = true;
			this.woaEnableOnBatteryFalseRadioButton.Text = "False";
			this.woaEnableOnBatteryFalseRadioButton.UseVisualStyleBackColor = true;
			this.woaEnableOnBatteryFalseRadioButton.CheckedChanged += new System.EventHandler(this.woaEnableOnBatteryFalse_radio_CheckedChanged);
			// 
			// woaEnableOnBatteryTrueRadioButton
			// 
			this.woaEnableOnBatteryTrueRadioButton.AutoSize = true;
			this.woaEnableOnBatteryTrueRadioButton.Checked = true;
			this.woaEnableOnBatteryTrueRadioButton.Location = new System.Drawing.Point(148, 2);
			this.woaEnableOnBatteryTrueRadioButton.Name = "woaEnableOnBatteryTrueRadioButton";
			this.woaEnableOnBatteryTrueRadioButton.Size = new System.Drawing.Size(47, 17);
			this.woaEnableOnBatteryTrueRadioButton.TabIndex = 35;
			this.woaEnableOnBatteryTrueRadioButton.TabStop = true;
			this.woaEnableOnBatteryTrueRadioButton.Text = "True";
			this.woaEnableOnBatteryTrueRadioButton.UseVisualStyleBackColor = true;
			this.woaEnableOnBatteryTrueRadioButton.CheckedChanged += new System.EventHandler(this.woaEnableOnBatteryTrue_radio_CheckedChanged);
			// 
			// woaEnableOnBatteryLabel
			// 
			this.woaEnableOnBatteryLabel.AutoSize = true;
			this.woaEnableOnBatteryLabel.Location = new System.Drawing.Point(4, 3);
			this.woaEnableOnBatteryLabel.Name = "woaEnableOnBatteryLabel";
			this.woaEnableOnBatteryLabel.Size = new System.Drawing.Size(116, 13);
			this.woaEnableOnBatteryLabel.TabIndex = 34;
			this.woaEnableOnBatteryLabel.Text = "Enable On Low Battery";
			// 
			// panel5
			// 
			this.panel5.Controls.Add(this.woaExternalMonitorOffRadioButton);
			this.panel5.Controls.Add(this.woaExternalMonitorOnRadioButton);
			this.panel5.Controls.Add(this.woaExternalMonitorLabel);
			this.panel5.Location = new System.Drawing.Point(3, 3);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(242, 22);
			this.panel5.TabIndex = 82;
			// 
			// woaExternalMonitorOffRadioButton
			// 
			this.woaExternalMonitorOffRadioButton.AutoSize = true;
			this.woaExternalMonitorOffRadioButton.Location = new System.Drawing.Point(203, 2);
			this.woaExternalMonitorOffRadioButton.Name = "woaExternalMonitorOffRadioButton";
			this.woaExternalMonitorOffRadioButton.Size = new System.Drawing.Size(39, 17);
			this.woaExternalMonitorOffRadioButton.TabIndex = 28;
			this.woaExternalMonitorOffRadioButton.TabStop = true;
			this.woaExternalMonitorOffRadioButton.Text = "Off";
			this.woaExternalMonitorOffRadioButton.UseVisualStyleBackColor = true;
			this.woaExternalMonitorOffRadioButton.CheckedChanged += new System.EventHandler(this.nearExternalMonitorOffRadioButton_CheckedChanged);
			// 
			// woaExternalMonitorOnRadioButton
			// 
			this.woaExternalMonitorOnRadioButton.AutoSize = true;
			this.woaExternalMonitorOnRadioButton.Checked = true;
			this.woaExternalMonitorOnRadioButton.Location = new System.Drawing.Point(160, 2);
			this.woaExternalMonitorOnRadioButton.Name = "woaExternalMonitorOnRadioButton";
			this.woaExternalMonitorOnRadioButton.Size = new System.Drawing.Size(39, 17);
			this.woaExternalMonitorOnRadioButton.TabIndex = 27;
			this.woaExternalMonitorOnRadioButton.TabStop = true;
			this.woaExternalMonitorOnRadioButton.Text = "On";
			this.woaExternalMonitorOnRadioButton.UseVisualStyleBackColor = true;
			this.woaExternalMonitorOnRadioButton.CheckedChanged += new System.EventHandler(this.nearExternalMonitorOnRadioButton_CheckedChanged);
			// 
			// woaExternalMonitorLabel
			// 
			this.woaExternalMonitorLabel.AutoSize = true;
			this.woaExternalMonitorLabel.Location = new System.Drawing.Point(6, 3);
			this.woaExternalMonitorLabel.Name = "woaExternalMonitorLabel";
			this.woaExternalMonitorLabel.Size = new System.Drawing.Size(144, 13);
			this.woaExternalMonitorLabel.TabIndex = 29;
			this.woaExternalMonitorLabel.Text = "Enable With External Monitor";
			// 
			// notPresentDimTargetLabel
			// 
			this.notPresentDimTargetLabel.AutoSize = true;
			this.notPresentDimTargetLabel.Location = new System.Drawing.Point(5, 79);
			this.notPresentDimTargetLabel.Name = "notPresentDimTargetLabel";
			this.notPresentDimTargetLabel.Size = new System.Drawing.Size(59, 13);
			this.notPresentDimTargetLabel.TabIndex = 71;
			this.notPresentDimTargetLabel.Text = "Dim Target";
			// 
			// notPresentDimTargetComboBox
			// 
			this.notPresentDimTargetComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.notPresentDimTargetComboBox.FormattingEnabled = true;
			this.notPresentDimTargetComboBox.Location = new System.Drawing.Point(164, 75);
			this.notPresentDimTargetComboBox.Name = "notPresentDimTargetComboBox";
			this.notPresentDimTargetComboBox.Size = new System.Drawing.Size(75, 21);
			this.notPresentDimTargetComboBox.TabIndex = 70;
			this.notPresentDimTargetComboBox.SelectedIndexChanged += new System.EventHandler(this.notPresentDimTargetComboBox_SelectedIndexChanged);
			// 
			// lockAfterDimIntervalLabel
			// 
			this.lockAfterDimIntervalLabel.AutoSize = true;
			this.lockAfterDimIntervalLabel.Location = new System.Drawing.Point(7, 206);
			this.lockAfterDimIntervalLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lockAfterDimIntervalLabel.Name = "lockAfterDimIntervalLabel";
			this.lockAfterDimIntervalLabel.Size = new System.Drawing.Size(114, 13);
			this.lockAfterDimIntervalLabel.TabIndex = 24;
			this.lockAfterDimIntervalLabel.Text = "Time to Lock after Dim";
			// 
			// lockAfterDimIntervalComboBox
			// 
			this.lockAfterDimIntervalComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.lockAfterDimIntervalComboBox.FormattingEnabled = true;
			this.lockAfterDimIntervalComboBox.Location = new System.Drawing.Point(151, 203);
			this.lockAfterDimIntervalComboBox.Name = "lockAfterDimIntervalComboBox";
			this.lockAfterDimIntervalComboBox.Size = new System.Drawing.Size(87, 21);
			this.lockAfterDimIntervalComboBox.TabIndex = 25;
			this.lockAfterDimIntervalComboBox.SelectedIndexChanged += new System.EventHandler(this.lockIntervalComboBox_SelectedIndexChanged);
			// 
			// userPresentWaitIntervalLabel
			// 
			this.userPresentWaitIntervalLabel.AutoSize = true;
			this.userPresentWaitIntervalLabel.Location = new System.Drawing.Point(5, 105);
			this.userPresentWaitIntervalLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.userPresentWaitIntervalLabel.Name = "userPresentWaitIntervalLabel";
			this.userPresentWaitIntervalLabel.Size = new System.Drawing.Size(89, 13);
			this.userPresentWaitIntervalLabel.TabIndex = 22;
			this.userPresentWaitIntervalLabel.Text = "Reset Wait Timer";
			// 
			// userPresentWaitIntervalComboBox
			// 
			this.userPresentWaitIntervalComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.userPresentWaitIntervalComboBox.FormattingEnabled = true;
			this.userPresentWaitIntervalComboBox.Location = new System.Drawing.Point(153, 100);
			this.userPresentWaitIntervalComboBox.Name = "userPresentWaitIntervalComboBox";
			this.userPresentWaitIntervalComboBox.Size = new System.Drawing.Size(87, 21);
			this.userPresentWaitIntervalComboBox.TabIndex = 23;
			this.userPresentWaitIntervalComboBox.SelectedIndexChanged += new System.EventHandler(this.userPresentWaitIntervalComboBox_SelectedIndexChanged);
			// 
			// walPanel
			// 
			this.walPanel.Controls.Add(this.walLabel);
			this.walPanel.Controls.Add(this.walCheckBox);
			this.walPanel.Location = new System.Drawing.Point(8, 5);
			this.walPanel.Name = "walPanel";
			this.walPanel.Size = new System.Drawing.Size(206, 23);
			this.walPanel.TabIndex = 35;
			// 
			// woaPanel
			// 
			this.woaPanel.Controls.Add(this.woaCheckBox);
			this.woaPanel.Controls.Add(this.woaLabel);
			this.woaPanel.Location = new System.Drawing.Point(266, 10);
			this.woaPanel.Name = "woaPanel";
			this.woaPanel.Size = new System.Drawing.Size(200, 23);
			this.woaPanel.TabIndex = 36;
			// 
			// proximityDistanceValueLabel
			// 
			this.proximityDistanceValueLabel.AutoSize = true;
			this.proximityDistanceValueLabel.Location = new System.Drawing.Point(126, 10);
			this.proximityDistanceValueLabel.Name = "proximityDistanceValueLabel";
			this.proximityDistanceValueLabel.Size = new System.Drawing.Size(0, 13);
			this.proximityDistanceValueLabel.TabIndex = 37;
			// 
			// proximityDistancePanel
			// 
			this.proximityDistancePanel.Controls.Add(this.proximityDistanceLabel);
			this.proximityDistancePanel.Controls.Add(this.proximityDistanceValueLabel);
			this.proximityDistancePanel.Location = new System.Drawing.Point(6, 422);
			this.proximityDistancePanel.Name = "proximityDistancePanel";
			this.proximityDistancePanel.Size = new System.Drawing.Size(176, 32);
			this.proximityDistancePanel.TabIndex = 38;
			// 
			// proximityDistanceLabel
			// 
			this.proximityDistanceLabel.AutoSize = true;
			this.proximityDistanceLabel.Location = new System.Drawing.Point(2, 10);
			this.proximityDistanceLabel.Name = "proximityDistanceLabel";
			this.proximityDistanceLabel.Size = new System.Drawing.Size(118, 13);
			this.proximityDistanceLabel.TabIndex = 38;
			this.proximityDistanceLabel.Text = "Proximity Distance (mm)";
			// 
			// lineSeparator
			// 
			this.lineSeparator.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lineSeparator.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lineSeparator.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lineSeparator.Location = new System.Drawing.Point(11, 368);
			this.lineSeparator.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lineSeparator.Name = "lineSeparator";
			this.lineSeparator.Size = new System.Drawing.Size(1060, 2);
			this.lineSeparator.TabIndex = 39;
			// 
			// comboBoxWaitTimer
			// 
			this.comboBoxWaitTimer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxWaitTimer.FormattingEnabled = true;
			this.comboBoxWaitTimer.Location = new System.Drawing.Point(152, 29);
			this.comboBoxWaitTimer.Name = "comboBoxWaitTimer";
			this.comboBoxWaitTimer.Size = new System.Drawing.Size(84, 21);
			this.comboBoxWaitTimer.TabIndex = 0;
			this.comboBoxWaitTimer.SelectedIndexChanged += new System.EventHandler(this.waitIntervalComboBox_SelectedIndexChanged);
			// 
			// nlopWaitTimerLabel
			// 
			this.nlopWaitTimerLabel.AutoSize = true;
			this.nlopWaitTimerLabel.Location = new System.Drawing.Point(5, 34);
			this.nlopWaitTimerLabel.Name = "nlopWaitTimerLabel";
			this.nlopWaitTimerLabel.Size = new System.Drawing.Size(89, 13);
			this.nlopWaitTimerLabel.TabIndex = 3;
			this.nlopWaitTimerLabel.Text = "Reset Wait Timer";
			// 
			// panelNlop
			// 
			this.panelNlop.Controls.Add(this.panel8);
			this.panelNlop.Controls.Add(this.nlopFailSafeTimerLabel);
			this.panelNlop.Controls.Add(this.panel7);
			this.panelNlop.Controls.Add(this.nlopFailSafeTimeoutComboBox);
			this.panelNlop.Controls.Add(this.nlopBatteryRemainingComboBox);
			this.panelNlop.Controls.Add(this.nlopBatteryRemainingLabel);
			this.panelNlop.Controls.Add(this.nlopWaitTimerLabel);
			this.panelNlop.Controls.Add(this.comboBoxWaitTimer);
			this.panelNlop.Location = new System.Drawing.Point(266, 146);
			this.panelNlop.Name = "panelNlop";
			this.panelNlop.Size = new System.Drawing.Size(252, 128);
			this.panelNlop.TabIndex = 40;
			// 
			// panel8
			// 
			this.panel8.Controls.Add(this.nlopEnableOnBatteryFalseRadioButton);
			this.panel8.Controls.Add(this.nlopEnableOnBatteryTrueRadioButton);
			this.panel8.Controls.Add(this.nlopEnableOnBatteryLabel);
			this.panel8.Location = new System.Drawing.Point(5, 53);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(240, 22);
			this.panel8.TabIndex = 83;
			// 
			// nlopEnableOnBatteryFalseRadioButton
			// 
			this.nlopEnableOnBatteryFalseRadioButton.AutoSize = true;
			this.nlopEnableOnBatteryFalseRadioButton.Location = new System.Drawing.Point(187, 3);
			this.nlopEnableOnBatteryFalseRadioButton.Name = "nlopEnableOnBatteryFalseRadioButton";
			this.nlopEnableOnBatteryFalseRadioButton.Size = new System.Drawing.Size(50, 17);
			this.nlopEnableOnBatteryFalseRadioButton.TabIndex = 31;
			this.nlopEnableOnBatteryFalseRadioButton.TabStop = true;
			this.nlopEnableOnBatteryFalseRadioButton.Text = "False";
			this.nlopEnableOnBatteryFalseRadioButton.UseVisualStyleBackColor = true;
			this.nlopEnableOnBatteryFalseRadioButton.CheckedChanged += new System.EventHandler(this.nlopEnableOnBatteryFalse_radio_CheckedChanged);
			// 
			// nlopEnableOnBatteryTrueRadioButton
			// 
			this.nlopEnableOnBatteryTrueRadioButton.AutoSize = true;
			this.nlopEnableOnBatteryTrueRadioButton.Checked = true;
			this.nlopEnableOnBatteryTrueRadioButton.Location = new System.Drawing.Point(143, 3);
			this.nlopEnableOnBatteryTrueRadioButton.Name = "nlopEnableOnBatteryTrueRadioButton";
			this.nlopEnableOnBatteryTrueRadioButton.Size = new System.Drawing.Size(47, 17);
			this.nlopEnableOnBatteryTrueRadioButton.TabIndex = 30;
			this.nlopEnableOnBatteryTrueRadioButton.TabStop = true;
			this.nlopEnableOnBatteryTrueRadioButton.Text = "True";
			this.nlopEnableOnBatteryTrueRadioButton.UseVisualStyleBackColor = true;
			this.nlopEnableOnBatteryTrueRadioButton.CheckedChanged += new System.EventHandler(this.nlopEnableOnBatteryTrue_radio_CheckedChanged);
			// 
			// nlopEnableOnBatteryLabel
			// 
			this.nlopEnableOnBatteryLabel.AutoSize = true;
			this.nlopEnableOnBatteryLabel.Location = new System.Drawing.Point(2, 5);
			this.nlopEnableOnBatteryLabel.Name = "nlopEnableOnBatteryLabel";
			this.nlopEnableOnBatteryLabel.Size = new System.Drawing.Size(93, 13);
			this.nlopEnableOnBatteryLabel.TabIndex = 29;
			this.nlopEnableOnBatteryLabel.Text = "Enable On Battery";
			// 
			// nlopFailSafeTimerLabel
			// 
			this.nlopFailSafeTimerLabel.AutoSize = true;
			this.nlopFailSafeTimerLabel.Location = new System.Drawing.Point(7, 107);
			this.nlopFailSafeTimerLabel.Name = "nlopFailSafeTimerLabel";
			this.nlopFailSafeTimerLabel.Size = new System.Drawing.Size(87, 13);
			this.nlopFailSafeTimerLabel.TabIndex = 35;
			this.nlopFailSafeTimerLabel.Text = "Fail-safe Timeout";
			// 
			// panel7
			// 
			this.panel7.Controls.Add(this.nlopExternalMonitorOffRadioButton);
			this.panel7.Controls.Add(this.nlopExternalMonitorOnRadioButton);
			this.panel7.Controls.Add(this.nlopExternalMonitorLabel);
			this.panel7.Location = new System.Drawing.Point(5, 3);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(240, 22);
			this.panel7.TabIndex = 83;
			// 
			// nlopExternalMonitorOffRadioButton
			// 
			this.nlopExternalMonitorOffRadioButton.AutoSize = true;
			this.nlopExternalMonitorOffRadioButton.Location = new System.Drawing.Point(198, 3);
			this.nlopExternalMonitorOffRadioButton.Name = "nlopExternalMonitorOffRadioButton";
			this.nlopExternalMonitorOffRadioButton.Size = new System.Drawing.Size(39, 17);
			this.nlopExternalMonitorOffRadioButton.TabIndex = 35;
			this.nlopExternalMonitorOffRadioButton.TabStop = true;
			this.nlopExternalMonitorOffRadioButton.Text = "Off";
			this.nlopExternalMonitorOffRadioButton.UseVisualStyleBackColor = true;
			this.nlopExternalMonitorOffRadioButton.CheckedChanged += new System.EventHandler(this.nlopExternalMonitorOffRadioButton_CheckedChanged);
			// 
			// nlopExternalMonitorOnRadioButton
			// 
			this.nlopExternalMonitorOnRadioButton.AutoSize = true;
			this.nlopExternalMonitorOnRadioButton.Checked = true;
			this.nlopExternalMonitorOnRadioButton.Location = new System.Drawing.Point(152, 3);
			this.nlopExternalMonitorOnRadioButton.Name = "nlopExternalMonitorOnRadioButton";
			this.nlopExternalMonitorOnRadioButton.Size = new System.Drawing.Size(39, 17);
			this.nlopExternalMonitorOnRadioButton.TabIndex = 34;
			this.nlopExternalMonitorOnRadioButton.TabStop = true;
			this.nlopExternalMonitorOnRadioButton.Text = "On";
			this.nlopExternalMonitorOnRadioButton.UseVisualStyleBackColor = true;
			this.nlopExternalMonitorOnRadioButton.CheckedChanged += new System.EventHandler(this.nlopExternalMonitorOnRadioButton_CheckedChanged);
			// 
			// nlopExternalMonitorLabel
			// 
			this.nlopExternalMonitorLabel.AutoSize = true;
			this.nlopExternalMonitorLabel.Location = new System.Drawing.Point(5, 5);
			this.nlopExternalMonitorLabel.Name = "nlopExternalMonitorLabel";
			this.nlopExternalMonitorLabel.Size = new System.Drawing.Size(144, 13);
			this.nlopExternalMonitorLabel.TabIndex = 36;
			this.nlopExternalMonitorLabel.Text = "Enable With External Monitor";
			// 
			// nlopFailSafeTimeoutComboBox
			// 
			this.nlopFailSafeTimeoutComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.nlopFailSafeTimeoutComboBox.FormattingEnabled = true;
			this.nlopFailSafeTimeoutComboBox.Location = new System.Drawing.Point(139, 103);
			this.nlopFailSafeTimeoutComboBox.Name = "nlopFailSafeTimeoutComboBox";
			this.nlopFailSafeTimeoutComboBox.Size = new System.Drawing.Size(96, 21);
			this.nlopFailSafeTimeoutComboBox.TabIndex = 34;
			this.nlopFailSafeTimeoutComboBox.SelectedIndexChanged += new System.EventHandler(this.failSafeTimeoutComboBox_SelectedIndexChanged);
			// 
			// nlopBatteryRemainingComboBox
			// 
			this.nlopBatteryRemainingComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.nlopBatteryRemainingComboBox.FormattingEnabled = true;
			this.nlopBatteryRemainingComboBox.Location = new System.Drawing.Point(162, 79);
			this.nlopBatteryRemainingComboBox.Name = "nlopBatteryRemainingComboBox";
			this.nlopBatteryRemainingComboBox.Size = new System.Drawing.Size(73, 21);
			this.nlopBatteryRemainingComboBox.TabIndex = 30;
			this.nlopBatteryRemainingComboBox.SelectedIndexChanged += new System.EventHandler(this.nlopBatteryComboBox_SelectedIndexChanged);
			// 
			// nlopBatteryRemainingLabel
			// 
			this.nlopBatteryRemainingLabel.AutoSize = true;
			this.nlopBatteryRemainingLabel.Location = new System.Drawing.Point(5, 84);
			this.nlopBatteryRemainingLabel.Name = "nlopBatteryRemainingLabel";
			this.nlopBatteryRemainingLabel.Size = new System.Drawing.Size(105, 13);
			this.nlopBatteryRemainingLabel.TabIndex = 29;
			this.nlopBatteryRemainingLabel.Text = "Low Battery Fail-safe";
			// 
			// groupBoxTrigger
			// 
			this.groupBoxTrigger.Controls.Add(this.buttonTiggerStop);
			this.groupBoxTrigger.Controls.Add(this.buttonTriggerStart);
			this.groupBoxTrigger.Location = new System.Drawing.Point(8, 376);
			this.groupBoxTrigger.Margin = new System.Windows.Forms.Padding(2);
			this.groupBoxTrigger.Name = "groupBoxTrigger";
			this.groupBoxTrigger.Padding = new System.Windows.Forms.Padding(2);
			this.groupBoxTrigger.Size = new System.Drawing.Size(149, 41);
			this.groupBoxTrigger.TabIndex = 42;
			this.groupBoxTrigger.TabStop = false;
			this.groupBoxTrigger.Text = "Service Trigger Start";
			// 
			// buttonTiggerStop
			// 
			this.buttonTiggerStop.Location = new System.Drawing.Point(77, 18);
			this.buttonTiggerStop.Margin = new System.Windows.Forms.Padding(2);
			this.buttonTiggerStop.Name = "buttonTiggerStop";
			this.buttonTiggerStop.Size = new System.Drawing.Size(56, 19);
			this.buttonTiggerStop.TabIndex = 1;
			this.buttonTiggerStop.Text = "Stop";
			this.buttonTiggerStop.UseVisualStyleBackColor = true;
			this.buttonTiggerStop.Click += new System.EventHandler(this.buttonTiggerStop_Click);
			// 
			// buttonTriggerStart
			// 
			this.buttonTriggerStart.Location = new System.Drawing.Point(8, 18);
			this.buttonTriggerStart.Margin = new System.Windows.Forms.Padding(2);
			this.buttonTriggerStart.Name = "buttonTriggerStart";
			this.buttonTriggerStart.Size = new System.Drawing.Size(56, 19);
			this.buttonTriggerStart.TabIndex = 0;
			this.buttonTriggerStart.Text = "Start";
			this.buttonTriggerStart.UseVisualStyleBackColor = true;
			this.buttonTriggerStart.Click += new System.EventHandler(this.buttonTriggerStart_Click);
			// 
			// nlopPanel
			// 
			this.nlopPanel.Controls.Add(this.nlopCheckBox);
			this.nlopPanel.Controls.Add(this.nlopLabel);
			this.nlopPanel.Location = new System.Drawing.Point(266, 121);
			this.nlopPanel.Name = "nlopPanel";
			this.nlopPanel.Size = new System.Drawing.Size(206, 23);
			this.nlopPanel.TabIndex = 56;
			// 
			// nlopCheckBox
			// 
			this.nlopCheckBox.AutoSize = true;
			this.nlopCheckBox.Location = new System.Drawing.Point(185, 5);
			this.nlopCheckBox.Name = "nlopCheckBox";
			this.nlopCheckBox.Size = new System.Drawing.Size(15, 14);
			this.nlopCheckBox.TabIndex = 4;
			this.nlopCheckBox.UseVisualStyleBackColor = true;
			this.nlopCheckBox.CheckedChanged += new System.EventHandler(this.checkBoxNlop_CheckedChanged);
			this.nlopCheckBox.EnabledChanged += new System.EventHandler(this.checkBoxNlop_EnabledChanged);
			// 
			// nlopLabel
			// 
			this.nlopLabel.AutoSize = true;
			this.nlopLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.nlopLabel.Location = new System.Drawing.Point(6, 4);
			this.nlopLabel.Name = "nlopLabel";
			this.nlopLabel.Size = new System.Drawing.Size(134, 14);
			this.nlopLabel.TabIndex = 3;
			this.nlopLabel.Text = "No Lock On Presence";
			// 
			// panelWal
			// 
			this.panelWal.Controls.Add(this.notPresentDimmingTimeLabel);
			this.panelWal.Controls.Add(this.notPresentDimmingTimeComboBox);
			this.panelWal.Controls.Add(this.panel4);
			this.panelWal.Controls.Add(this.panel3);
			this.panelWal.Controls.Add(this.panel2);
			this.panelWal.Controls.Add(this.dimScreenPanel);
			this.panelWal.Controls.Add(this.walExternalMonitorPanel);
			this.panelWal.Controls.Add(this.preDimIntervalLabel);
			this.panelWal.Controls.Add(this.preDimIntervalComboBox);
			this.panelWal.Controls.Add(this.notPresentDimTargetLabel);
			this.panelWal.Controls.Add(this.notPresentDimTargetComboBox);
			this.panelWal.Controls.Add(this.userPresentWaitIntervalLabel);
			this.panelWal.Controls.Add(this.userPresentWaitIntervalComboBox);
			this.panelWal.Controls.Add(this.lockAfterDimIntervalLabel);
			this.panelWal.Controls.Add(this.lockAfterDimIntervalComboBox);
			this.panelWal.Location = new System.Drawing.Point(8, 32);
			this.panelWal.Name = "panelWal";
			this.panelWal.Size = new System.Drawing.Size(248, 252);
			this.panelWal.TabIndex = 36;
			// 
			// notPresentDimmingTimeLabel
			// 
			this.notPresentDimmingTimeLabel.AutoSize = true;
			this.notPresentDimmingTimeLabel.Location = new System.Drawing.Point(4, 53);
			this.notPresentDimmingTimeLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.notPresentDimmingTimeLabel.Name = "notPresentDimmingTimeLabel";
			this.notPresentDimmingTimeLabel.Size = new System.Drawing.Size(73, 13);
			this.notPresentDimmingTimeLabel.TabIndex = 85;
			this.notPresentDimmingTimeLabel.Text = "Dimming Time";
			// 
			// notPresentDimmingTimeComboBox
			// 
			this.notPresentDimmingTimeComboBox.AllowDrop = true;
			this.notPresentDimmingTimeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.notPresentDimmingTimeComboBox.FormattingEnabled = true;
			this.notPresentDimmingTimeComboBox.Location = new System.Drawing.Point(153, 52);
			this.notPresentDimmingTimeComboBox.Name = "notPresentDimmingTimeComboBox";
			this.notPresentDimmingTimeComboBox.Size = new System.Drawing.Size(87, 21);
			this.notPresentDimmingTimeComboBox.TabIndex = 86;
			this.notPresentDimmingTimeComboBox.SelectedIndexChanged += new System.EventHandler(this.notPresentDimmingTimeComboBox_SelectedIndexChanged);
			// 
			// panel4
			// 
			this.panel4.Controls.Add(this.displayOffOnRadioButton);
			this.panel4.Controls.Add(this.displayOffOffRadioButton);
			this.panel4.Controls.Add(this.displayOffAfterLockLabel);
			this.panel4.Location = new System.Drawing.Point(4, 225);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(236, 22);
			this.panel4.TabIndex = 84;
			// 
			// displayOffOnRadioButton
			// 
			this.displayOffOnRadioButton.AutoSize = true;
			this.displayOffOnRadioButton.Checked = true;
			this.displayOffOnRadioButton.Location = new System.Drawing.Point(152, 3);
			this.displayOffOnRadioButton.Name = "displayOffOnRadioButton";
			this.displayOffOnRadioButton.Size = new System.Drawing.Size(39, 17);
			this.displayOffOnRadioButton.TabIndex = 81;
			this.displayOffOnRadioButton.TabStop = true;
			this.displayOffOnRadioButton.Text = "On";
			this.displayOffOnRadioButton.UseVisualStyleBackColor = true;
			this.displayOffOnRadioButton.CheckedChanged += new System.EventHandler(this.displayOffOnRadioButton_CheckedChanged);
			// 
			// displayOffOffRadioButton
			// 
			this.displayOffOffRadioButton.AutoSize = true;
			this.displayOffOffRadioButton.Location = new System.Drawing.Point(196, 3);
			this.displayOffOffRadioButton.Name = "displayOffOffRadioButton";
			this.displayOffOffRadioButton.Size = new System.Drawing.Size(39, 17);
			this.displayOffOffRadioButton.TabIndex = 82;
			this.displayOffOffRadioButton.TabStop = true;
			this.displayOffOffRadioButton.Text = "Off";
			this.displayOffOffRadioButton.UseVisualStyleBackColor = true;
			this.displayOffOffRadioButton.CheckedChanged += new System.EventHandler(this.displayOffOffRadioButton_CheckedChanged);
			// 
			// displayOffAfterLockLabel
			// 
			this.displayOffAfterLockLabel.AutoSize = true;
			this.displayOffAfterLockLabel.Location = new System.Drawing.Point(5, 6);
			this.displayOffAfterLockLabel.Name = "displayOffAfterLockLabel";
			this.displayOffAfterLockLabel.Size = new System.Drawing.Size(110, 13);
			this.displayOffAfterLockLabel.TabIndex = 80;
			this.displayOffAfterLockLabel.Text = "Display Off After Lock";
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this.honorUserInCallOnRadioButton);
			this.panel3.Controls.Add(this.honorUserInCallOffRadioButton);
			this.panel3.Controls.Add(this.honorUserInCallLabel);
			this.panel3.Location = new System.Drawing.Point(3, 179);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(236, 22);
			this.panel3.TabIndex = 83;
			// 
			// honorUserInCallOnRadioButton
			// 
			this.honorUserInCallOnRadioButton.AutoSize = true;
			this.honorUserInCallOnRadioButton.Checked = true;
			this.honorUserInCallOnRadioButton.Location = new System.Drawing.Point(150, 3);
			this.honorUserInCallOnRadioButton.Name = "honorUserInCallOnRadioButton";
			this.honorUserInCallOnRadioButton.Size = new System.Drawing.Size(39, 17);
			this.honorUserInCallOnRadioButton.TabIndex = 79;
			this.honorUserInCallOnRadioButton.TabStop = true;
			this.honorUserInCallOnRadioButton.Text = "On";
			this.honorUserInCallOnRadioButton.UseVisualStyleBackColor = true;
			this.honorUserInCallOnRadioButton.CheckedChanged += new System.EventHandler(this.honorUserInCallOnRadioButton_CheckedChanged);
			// 
			// honorUserInCallOffRadioButton
			// 
			this.honorUserInCallOffRadioButton.AutoSize = true;
			this.honorUserInCallOffRadioButton.Location = new System.Drawing.Point(195, 3);
			this.honorUserInCallOffRadioButton.Name = "honorUserInCallOffRadioButton";
			this.honorUserInCallOffRadioButton.Size = new System.Drawing.Size(39, 17);
			this.honorUserInCallOffRadioButton.TabIndex = 80;
			this.honorUserInCallOffRadioButton.TabStop = true;
			this.honorUserInCallOffRadioButton.Text = "Off";
			this.honorUserInCallOffRadioButton.UseVisualStyleBackColor = true;
			this.honorUserInCallOffRadioButton.CheckedChanged += new System.EventHandler(this.honorUserInCallOffRadioButton_CheckedChanged);
			// 
			// honorUserInCallLabel
			// 
			this.honorUserInCallLabel.AutoSize = true;
			this.honorUserInCallLabel.Location = new System.Drawing.Point(6, 3);
			this.honorUserInCallLabel.Name = "honorUserInCallLabel";
			this.honorUserInCallLabel.Size = new System.Drawing.Size(93, 13);
			this.honorUserInCallLabel.TabIndex = 78;
			this.honorUserInCallLabel.Text = "Honor User In Call";
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.honorPowerRequestsOnRadioButton);
			this.panel2.Controls.Add(this.honorPowerRequestsOffRadioButton);
			this.panel2.Controls.Add(this.honorPowerRequestsLabel);
			this.panel2.Location = new System.Drawing.Point(3, 150);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(236, 22);
			this.panel2.TabIndex = 83;
			// 
			// honorPowerRequestsOnRadioButton
			// 
			this.honorPowerRequestsOnRadioButton.AutoSize = true;
			this.honorPowerRequestsOnRadioButton.Checked = true;
			this.honorPowerRequestsOnRadioButton.Location = new System.Drawing.Point(151, 3);
			this.honorPowerRequestsOnRadioButton.Name = "honorPowerRequestsOnRadioButton";
			this.honorPowerRequestsOnRadioButton.Size = new System.Drawing.Size(39, 17);
			this.honorPowerRequestsOnRadioButton.TabIndex = 77;
			this.honorPowerRequestsOnRadioButton.TabStop = true;
			this.honorPowerRequestsOnRadioButton.Text = "On";
			this.honorPowerRequestsOnRadioButton.UseVisualStyleBackColor = true;
			this.honorPowerRequestsOnRadioButton.CheckedChanged += new System.EventHandler(this.honorPowerRequestsOnRadioButton_CheckedChanged);
			// 
			// honorPowerRequestsOffRadioButton
			// 
			this.honorPowerRequestsOffRadioButton.AutoSize = true;
			this.honorPowerRequestsOffRadioButton.Location = new System.Drawing.Point(196, 3);
			this.honorPowerRequestsOffRadioButton.Name = "honorPowerRequestsOffRadioButton";
			this.honorPowerRequestsOffRadioButton.Size = new System.Drawing.Size(39, 17);
			this.honorPowerRequestsOffRadioButton.TabIndex = 78;
			this.honorPowerRequestsOffRadioButton.TabStop = true;
			this.honorPowerRequestsOffRadioButton.Text = "Off";
			this.honorPowerRequestsOffRadioButton.UseVisualStyleBackColor = true;
			this.honorPowerRequestsOffRadioButton.CheckedChanged += new System.EventHandler(this.honorPowerRequestsOffRadioButton_CheckedChanged);
			// 
			// honorPowerRequestsLabel
			// 
			this.honorPowerRequestsLabel.AutoSize = true;
			this.honorPowerRequestsLabel.Location = new System.Drawing.Point(3, 4);
			this.honorPowerRequestsLabel.Name = "honorPowerRequestsLabel";
			this.honorPowerRequestsLabel.Size = new System.Drawing.Size(117, 13);
			this.honorPowerRequestsLabel.TabIndex = 76;
			this.honorPowerRequestsLabel.Text = "Honor Power Requests";
			// 
			// dimScreenPanel
			// 
			this.dimScreenPanel.Controls.Add(this.dimScreenOnRadioButton);
			this.dimScreenPanel.Controls.Add(this.dimScreenOffRadioButton);
			this.dimScreenPanel.Controls.Add(this.dimScreenLabel);
			this.dimScreenPanel.Location = new System.Drawing.Point(3, 122);
			this.dimScreenPanel.Name = "dimScreenPanel";
			this.dimScreenPanel.Size = new System.Drawing.Size(236, 22);
			this.dimScreenPanel.TabIndex = 81;
			// 
			// dimScreenOnRadioButton
			// 
			this.dimScreenOnRadioButton.AutoSize = true;
			this.dimScreenOnRadioButton.Checked = true;
			this.dimScreenOnRadioButton.Location = new System.Drawing.Point(152, 3);
			this.dimScreenOnRadioButton.Name = "dimScreenOnRadioButton";
			this.dimScreenOnRadioButton.Size = new System.Drawing.Size(39, 17);
			this.dimScreenOnRadioButton.TabIndex = 75;
			this.dimScreenOnRadioButton.TabStop = true;
			this.dimScreenOnRadioButton.Text = "On";
			this.dimScreenOnRadioButton.UseVisualStyleBackColor = true;
			this.dimScreenOnRadioButton.CheckedChanged += new System.EventHandler(this.dimScreenOnRadioButton_CheckedChanged);
			// 
			// dimScreenOffRadioButton
			// 
			this.dimScreenOffRadioButton.AutoSize = true;
			this.dimScreenOffRadioButton.Location = new System.Drawing.Point(196, 3);
			this.dimScreenOffRadioButton.Name = "dimScreenOffRadioButton";
			this.dimScreenOffRadioButton.Size = new System.Drawing.Size(39, 17);
			this.dimScreenOffRadioButton.TabIndex = 76;
			this.dimScreenOffRadioButton.TabStop = true;
			this.dimScreenOffRadioButton.Text = "Off";
			this.dimScreenOffRadioButton.UseVisualStyleBackColor = true;
			this.dimScreenOffRadioButton.CheckedChanged += new System.EventHandler(this.dimScreenOffRadioButton_CheckedChanged);
			// 
			// dimScreenLabel
			// 
			this.dimScreenLabel.AutoSize = true;
			this.dimScreenLabel.Location = new System.Drawing.Point(3, 5);
			this.dimScreenLabel.Name = "dimScreenLabel";
			this.dimScreenLabel.Size = new System.Drawing.Size(62, 13);
			this.dimScreenLabel.TabIndex = 74;
			this.dimScreenLabel.Text = "Dim Screen";
			// 
			// walExternalMonitorPanel
			// 
			this.walExternalMonitorPanel.Controls.Add(this.walExternalMonitorLabel);
			this.walExternalMonitorPanel.Controls.Add(this.walExternalMonitorOnRadioButton);
			this.walExternalMonitorPanel.Controls.Add(this.walExternalMonitorOffRadioButton);
			this.walExternalMonitorPanel.Location = new System.Drawing.Point(1, 5);
			this.walExternalMonitorPanel.Name = "walExternalMonitorPanel";
			this.walExternalMonitorPanel.Size = new System.Drawing.Size(238, 22);
			this.walExternalMonitorPanel.TabIndex = 80;
			// 
			// walExternalMonitorLabel
			// 
			this.walExternalMonitorLabel.AutoSize = true;
			this.walExternalMonitorLabel.Location = new System.Drawing.Point(3, 6);
			this.walExternalMonitorLabel.Name = "walExternalMonitorLabel";
			this.walExternalMonitorLabel.Size = new System.Drawing.Size(144, 13);
			this.walExternalMonitorLabel.TabIndex = 43;
			this.walExternalMonitorLabel.Text = "Enable With External Monitor";
			// 
			// walExternalMonitorOnRadioButton
			// 
			this.walExternalMonitorOnRadioButton.AutoSize = true;
			this.walExternalMonitorOnRadioButton.Checked = true;
			this.walExternalMonitorOnRadioButton.Location = new System.Drawing.Point(153, 3);
			this.walExternalMonitorOnRadioButton.Name = "walExternalMonitorOnRadioButton";
			this.walExternalMonitorOnRadioButton.Size = new System.Drawing.Size(39, 17);
			this.walExternalMonitorOnRadioButton.TabIndex = 41;
			this.walExternalMonitorOnRadioButton.TabStop = true;
			this.walExternalMonitorOnRadioButton.Text = "On";
			this.walExternalMonitorOnRadioButton.UseVisualStyleBackColor = true;
			this.walExternalMonitorOnRadioButton.CheckedChanged += new System.EventHandler(this.awayExternalMonitorOnRadioButton_CheckedChanged);
			// 
			// walExternalMonitorOffRadioButton
			// 
			this.walExternalMonitorOffRadioButton.AutoSize = true;
			this.walExternalMonitorOffRadioButton.Location = new System.Drawing.Point(198, 3);
			this.walExternalMonitorOffRadioButton.Name = "walExternalMonitorOffRadioButton";
			this.walExternalMonitorOffRadioButton.Size = new System.Drawing.Size(39, 17);
			this.walExternalMonitorOffRadioButton.TabIndex = 42;
			this.walExternalMonitorOffRadioButton.TabStop = true;
			this.walExternalMonitorOffRadioButton.Text = "Off";
			this.walExternalMonitorOffRadioButton.UseVisualStyleBackColor = true;
			this.walExternalMonitorOffRadioButton.CheckedChanged += new System.EventHandler(this.awayExternalMonitorOffRadioButton_CheckedChanged);
			// 
			// adPanel
			// 
			this.adPanel.Controls.Add(this.adCheckBox);
			this.adPanel.Controls.Add(this.adLabel);
			this.adPanel.Location = new System.Drawing.Point(532, 9);
			this.adPanel.Name = "adPanel";
			this.adPanel.Size = new System.Drawing.Size(206, 23);
			this.adPanel.TabIndex = 57;
			// 
			// adCheckBox
			// 
			this.adCheckBox.AutoSize = true;
			this.adCheckBox.Location = new System.Drawing.Point(185, 4);
			this.adCheckBox.Name = "adCheckBox";
			this.adCheckBox.Size = new System.Drawing.Size(15, 14);
			this.adCheckBox.TabIndex = 55;
			this.adCheckBox.UseVisualStyleBackColor = true;
			this.adCheckBox.CheckedChanged += new System.EventHandler(this.checkBoxAd_CheckedChanged);
			this.adCheckBox.EnabledChanged += new System.EventHandler(this.checkBoxAd_EnabledChanged);
			// 
			// adLabel
			// 
			this.adLabel.AutoSize = true;
			this.adLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.adLabel.Location = new System.Drawing.Point(6, 4);
			this.adLabel.Name = "adLabel";
			this.adLabel.Size = new System.Drawing.Size(119, 14);
			this.adLabel.TabIndex = 54;
			this.adLabel.Text = "Adaptive Dimming";
			// 
			// panelAd
			// 
			this.panelAd.Controls.Add(this.panel10);
			this.panelAd.Controls.Add(this.panel9);
			this.panelAd.Controls.Add(this.dimWaitDisengagedAdLabel);
			this.panelAd.Controls.Add(this.adDisengagedDimWaitTimeComboBox);
			this.panelAd.Controls.Add(this.MP4DimWaitComboBox);
			this.panelAd.Controls.Add(this.MP4DimWaitLabel);
			this.panelAd.Controls.Add(this.MP3DimWaitComboBox);
			this.panelAd.Controls.Add(this.MP3DimWaitLabel);
			this.panelAd.Controls.Add(this.panel1);
			this.panelAd.Controls.Add(this.dimTargetLabel);
			this.panelAd.Controls.Add(this.adDimTargetComboBox);
			this.panelAd.Controls.Add(this.dimmingIntervalLabel);
			this.panelAd.Controls.Add(this.adDimmingIntervalComboBox);
			this.panelAd.Controls.Add(this.MP2DimWaitComboBox);
			this.panelAd.Controls.Add(this.MP2DimWaitLabel);
			this.panelAd.Controls.Add(this.MP1DimWaitComboBox);
			this.panelAd.Controls.Add(this.MP1DimWaitLabel);
			this.panelAd.Controls.Add(this.dimWaitNotPresentAdLabel);
			this.panelAd.Controls.Add(this.adNotPresentDimWaitTimeComboBox);
			this.panelAd.Controls.Add(this.mispredictionTimeLabel);
			this.panelAd.Controls.Add(this.mispredictionTimeWindowCombobox);
			this.panelAd.Controls.Add(this.mispredictionWithFaceDetectionCheckbox);
			this.panelAd.Controls.Add(this.mispredictionFaceDetectionLabel);
			this.panelAd.Location = new System.Drawing.Point(532, 39);
			this.panelAd.Name = "panelAd";
			this.panelAd.Size = new System.Drawing.Size(255, 325);
			this.panelAd.TabIndex = 58;
			// 
			// panel10
			// 
			this.panel10.Controls.Add(this.honorUserInCallADRadioButtonOn);
			this.panel10.Controls.Add(this.honorUserInCallADRadioButtonOff);
			this.panel10.Controls.Add(this.label2);
			this.panel10.Location = new System.Drawing.Point(2, 56);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(236, 22);
			this.panel10.TabIndex = 84;
			// 
			// honorUserInCallADRadioButtonOn
			// 
			this.honorUserInCallADRadioButtonOn.AutoSize = true;
			this.honorUserInCallADRadioButtonOn.Location = new System.Drawing.Point(150, 3);
			this.honorUserInCallADRadioButtonOn.Name = "honorUserInCallADRadioButtonOn";
			this.honorUserInCallADRadioButtonOn.Size = new System.Drawing.Size(39, 17);
			this.honorUserInCallADRadioButtonOn.TabIndex = 79;
			this.honorUserInCallADRadioButtonOn.TabStop = true;
			this.honorUserInCallADRadioButtonOn.Text = "On";
			this.honorUserInCallADRadioButtonOn.UseVisualStyleBackColor = true;
			this.honorUserInCallADRadioButtonOn.CheckedChanged += new System.EventHandler(this.honorUserInCallADRadioButtonOn_CheckedChanged);
			// 
			// honorUserInCallADRadioButtonOff
			// 
			this.honorUserInCallADRadioButtonOff.AutoSize = true;
			this.honorUserInCallADRadioButtonOff.Checked = true;
			this.honorUserInCallADRadioButtonOff.Location = new System.Drawing.Point(195, 3);
			this.honorUserInCallADRadioButtonOff.Name = "honorUserInCallADRadioButtonOff";
			this.honorUserInCallADRadioButtonOff.Size = new System.Drawing.Size(39, 17);
			this.honorUserInCallADRadioButtonOff.TabIndex = 80;
			this.honorUserInCallADRadioButtonOff.TabStop = true;
			this.honorUserInCallADRadioButtonOff.Text = "Off";
			this.honorUserInCallADRadioButtonOff.UseVisualStyleBackColor = true;
			this.honorUserInCallADRadioButtonOff.CheckedChanged += new System.EventHandler(this.honorUserInCallADRadioButtonOff_CheckedChanged);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(6, 3);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(93, 13);
			this.label2.TabIndex = 78;
			this.label2.Text = "Honor User In Call";
			// 
			// panel9
			// 
			this.panel9.Controls.Add(this.adHonorPowerRequestOffRadioButton);
			this.panel9.Controls.Add(this.adHonorPowerRequestOnRadioButton);
			this.panel9.Controls.Add(this.label1);
			this.panel9.Location = new System.Drawing.Point(3, 29);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(248, 22);
			this.panel9.TabIndex = 83;
			// 
			// adHonorPowerRequestOffRadioButton
			// 
			this.adHonorPowerRequestOffRadioButton.AutoSize = true;
			this.adHonorPowerRequestOffRadioButton.Checked = true;
			this.adHonorPowerRequestOffRadioButton.Location = new System.Drawing.Point(205, 3);
			this.adHonorPowerRequestOffRadioButton.Name = "adHonorPowerRequestOffRadioButton";
			this.adHonorPowerRequestOffRadioButton.Size = new System.Drawing.Size(39, 17);
			this.adHonorPowerRequestOffRadioButton.TabIndex = 76;
			this.adHonorPowerRequestOffRadioButton.TabStop = true;
			this.adHonorPowerRequestOffRadioButton.Text = "Off";
			this.adHonorPowerRequestOffRadioButton.UseVisualStyleBackColor = true;
			this.adHonorPowerRequestOffRadioButton.CheckedChanged += new System.EventHandler(this.adHonorPowerRequestOffRadioButton_CheckedChanged);
			// 
			// adHonorPowerRequestOnRadioButton
			// 
			this.adHonorPowerRequestOnRadioButton.AutoSize = true;
			this.adHonorPowerRequestOnRadioButton.Location = new System.Drawing.Point(160, 3);
			this.adHonorPowerRequestOnRadioButton.Name = "adHonorPowerRequestOnRadioButton";
			this.adHonorPowerRequestOnRadioButton.Size = new System.Drawing.Size(39, 17);
			this.adHonorPowerRequestOnRadioButton.TabIndex = 75;
			this.adHonorPowerRequestOnRadioButton.TabStop = true;
			this.adHonorPowerRequestOnRadioButton.Text = "On";
			this.adHonorPowerRequestOnRadioButton.UseVisualStyleBackColor = true;
			this.adHonorPowerRequestOnRadioButton.CheckedChanged += new System.EventHandler(this.adHonorPowerRequestOnRadioButton_CheckedChanged);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(3, 5);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(112, 13);
			this.label1.TabIndex = 77;
			this.label1.Text = "Honor Power Request";
			// 
			// dimWaitDisengagedAdLabel
			// 
			this.dimWaitDisengagedAdLabel.AutoSize = true;
			this.dimWaitDisengagedAdLabel.Location = new System.Drawing.Point(5, 158);
			this.dimWaitDisengagedAdLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.dimWaitDisengagedAdLabel.Name = "dimWaitDisengagedAdLabel";
			this.dimWaitDisengagedAdLabel.Size = new System.Drawing.Size(141, 13);
			this.dimWaitDisengagedAdLabel.TabIndex = 95;
			this.dimWaitDisengagedAdLabel.Text = "Time Until Dim (Disengaged)";
			// 
			// adDisengagedDimWaitTimeComboBox
			// 
			this.adDisengagedDimWaitTimeComboBox.AllowDrop = true;
			this.adDisengagedDimWaitTimeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.adDisengagedDimWaitTimeComboBox.FormattingEnabled = true;
			this.adDisengagedDimWaitTimeComboBox.Location = new System.Drawing.Point(151, 155);
			this.adDisengagedDimWaitTimeComboBox.Name = "adDisengagedDimWaitTimeComboBox";
			this.adDisengagedDimWaitTimeComboBox.Size = new System.Drawing.Size(93, 21);
			this.adDisengagedDimWaitTimeComboBox.TabIndex = 96;
			this.adDisengagedDimWaitTimeComboBox.SelectedIndexChanged += new System.EventHandler(this.adDisengagedDimWaitTimeComboBox_SelectedIndexChanged);
			// 
			// MP4DimWaitComboBox
			// 
			this.MP4DimWaitComboBox.AllowDrop = true;
			this.MP4DimWaitComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.MP4DimWaitComboBox.FormattingEnabled = true;
			this.MP4DimWaitComboBox.Location = new System.Drawing.Point(152, 250);
			this.MP4DimWaitComboBox.Name = "MP4DimWaitComboBox";
			this.MP4DimWaitComboBox.Size = new System.Drawing.Size(92, 21);
			this.MP4DimWaitComboBox.TabIndex = 94;
			this.MP4DimWaitComboBox.SelectedIndexChanged += new System.EventHandler(this.MP4DimWaitComboBox_SelectedIndexChanged);
			// 
			// MP4DimWaitLabel
			// 
			this.MP4DimWaitLabel.AutoSize = true;
			this.MP4DimWaitLabel.Location = new System.Drawing.Point(5, 254);
			this.MP4DimWaitLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.MP4DimWaitLabel.Name = "MP4DimWaitLabel";
			this.MP4DimWaitLabel.Size = new System.Drawing.Size(118, 13);
			this.MP4DimWaitLabel.TabIndex = 93;
			this.MP4DimWaitLabel.Text = "Time Until Dim (MP = 4)";
			// 
			// MP3DimWaitComboBox
			// 
			this.MP3DimWaitComboBox.AllowDrop = true;
			this.MP3DimWaitComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.MP3DimWaitComboBox.FormattingEnabled = true;
			this.MP3DimWaitComboBox.Location = new System.Drawing.Point(152, 227);
			this.MP3DimWaitComboBox.Name = "MP3DimWaitComboBox";
			this.MP3DimWaitComboBox.Size = new System.Drawing.Size(92, 21);
			this.MP3DimWaitComboBox.TabIndex = 92;
			this.MP3DimWaitComboBox.SelectedIndexChanged += new System.EventHandler(this.MP3DimWaitComboBox_SelectedIndexChanged);
			// 
			// MP3DimWaitLabel
			// 
			this.MP3DimWaitLabel.AutoSize = true;
			this.MP3DimWaitLabel.Location = new System.Drawing.Point(5, 230);
			this.MP3DimWaitLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.MP3DimWaitLabel.Name = "MP3DimWaitLabel";
			this.MP3DimWaitLabel.Size = new System.Drawing.Size(118, 13);
			this.MP3DimWaitLabel.TabIndex = 91;
			this.MP3DimWaitLabel.Text = "Time Until Dim (MP = 3)";
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.adExternalMonitorOffRadioButton);
			this.panel1.Controls.Add(this.adExternalMonitorOnRadioButton);
			this.panel1.Controls.Add(this.adExternalMonitorLabel);
			this.panel1.Location = new System.Drawing.Point(4, 3);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(248, 22);
			this.panel1.TabIndex = 82;
			// 
			// adExternalMonitorOffRadioButton
			// 
			this.adExternalMonitorOffRadioButton.AutoSize = true;
			this.adExternalMonitorOffRadioButton.Location = new System.Drawing.Point(205, 3);
			this.adExternalMonitorOffRadioButton.Name = "adExternalMonitorOffRadioButton";
			this.adExternalMonitorOffRadioButton.Size = new System.Drawing.Size(39, 17);
			this.adExternalMonitorOffRadioButton.TabIndex = 76;
			this.adExternalMonitorOffRadioButton.TabStop = true;
			this.adExternalMonitorOffRadioButton.Text = "Off";
			this.adExternalMonitorOffRadioButton.UseVisualStyleBackColor = true;
			this.adExternalMonitorOffRadioButton.CheckedChanged += new System.EventHandler(this.adExternalMonitorOffRadioButton_CheckedChanged);
			// 
			// adExternalMonitorOnRadioButton
			// 
			this.adExternalMonitorOnRadioButton.AutoSize = true;
			this.adExternalMonitorOnRadioButton.Checked = true;
			this.adExternalMonitorOnRadioButton.Location = new System.Drawing.Point(160, 3);
			this.adExternalMonitorOnRadioButton.Name = "adExternalMonitorOnRadioButton";
			this.adExternalMonitorOnRadioButton.Size = new System.Drawing.Size(39, 17);
			this.adExternalMonitorOnRadioButton.TabIndex = 75;
			this.adExternalMonitorOnRadioButton.TabStop = true;
			this.adExternalMonitorOnRadioButton.Text = "On";
			this.adExternalMonitorOnRadioButton.UseVisualStyleBackColor = true;
			this.adExternalMonitorOnRadioButton.CheckedChanged += new System.EventHandler(this.adExternalMonitorOnRadioButton_CheckedChanged);
			// 
			// adExternalMonitorLabel
			// 
			this.adExternalMonitorLabel.AutoSize = true;
			this.adExternalMonitorLabel.Location = new System.Drawing.Point(3, 5);
			this.adExternalMonitorLabel.Name = "adExternalMonitorLabel";
			this.adExternalMonitorLabel.Size = new System.Drawing.Size(144, 13);
			this.adExternalMonitorLabel.TabIndex = 77;
			this.adExternalMonitorLabel.Text = "Enable With External Monitor";
			// 
			// dimTargetLabel
			// 
			this.dimTargetLabel.AutoSize = true;
			this.dimTargetLabel.Location = new System.Drawing.Point(7, 301);
			this.dimTargetLabel.Name = "dimTargetLabel";
			this.dimTargetLabel.Size = new System.Drawing.Size(59, 13);
			this.dimTargetLabel.TabIndex = 88;
			this.dimTargetLabel.Text = "Dim Target";
			// 
			// adDimTargetComboBox
			// 
			this.adDimTargetComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.adDimTargetComboBox.FormattingEnabled = true;
			this.adDimTargetComboBox.Location = new System.Drawing.Point(169, 297);
			this.adDimTargetComboBox.Name = "adDimTargetComboBox";
			this.adDimTargetComboBox.Size = new System.Drawing.Size(75, 21);
			this.adDimTargetComboBox.TabIndex = 87;
			this.adDimTargetComboBox.SelectedIndexChanged += new System.EventHandler(this.adDimTargetComboBox_SelectedIndexChanged);
			// 
			// dimmingIntervalLabel
			// 
			this.dimmingIntervalLabel.AutoSize = true;
			this.dimmingIntervalLabel.Location = new System.Drawing.Point(7, 276);
			this.dimmingIntervalLabel.Name = "dimmingIntervalLabel";
			this.dimmingIntervalLabel.Size = new System.Drawing.Size(73, 13);
			this.dimmingIntervalLabel.TabIndex = 86;
			this.dimmingIntervalLabel.Text = "Dimming Time";
			// 
			// adDimmingIntervalComboBox
			// 
			this.adDimmingIntervalComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.adDimmingIntervalComboBox.FormattingEnabled = true;
			this.adDimmingIntervalComboBox.Location = new System.Drawing.Point(169, 273);
			this.adDimmingIntervalComboBox.Name = "adDimmingIntervalComboBox";
			this.adDimmingIntervalComboBox.Size = new System.Drawing.Size(75, 21);
			this.adDimmingIntervalComboBox.TabIndex = 85;
			this.adDimmingIntervalComboBox.SelectedIndexChanged += new System.EventHandler(this.adDimmingIntervalComboBox_SelectedIndexChanged);
			// 
			// MP2DimWaitComboBox
			// 
			this.MP2DimWaitComboBox.AllowDrop = true;
			this.MP2DimWaitComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.MP2DimWaitComboBox.FormattingEnabled = true;
			this.MP2DimWaitComboBox.Location = new System.Drawing.Point(152, 204);
			this.MP2DimWaitComboBox.Name = "MP2DimWaitComboBox";
			this.MP2DimWaitComboBox.Size = new System.Drawing.Size(92, 21);
			this.MP2DimWaitComboBox.TabIndex = 84;
			this.MP2DimWaitComboBox.SelectedIndexChanged += new System.EventHandler(this.MP2DimWaitComboBox_SelectedIndexChanged);
			// 
			// MP2DimWaitLabel
			// 
			this.MP2DimWaitLabel.AutoSize = true;
			this.MP2DimWaitLabel.Location = new System.Drawing.Point(5, 208);
			this.MP2DimWaitLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.MP2DimWaitLabel.Name = "MP2DimWaitLabel";
			this.MP2DimWaitLabel.Size = new System.Drawing.Size(118, 13);
			this.MP2DimWaitLabel.TabIndex = 83;
			this.MP2DimWaitLabel.Text = "Time Until Dim (MP = 2)";
			// 
			// MP1DimWaitComboBox
			// 
			this.MP1DimWaitComboBox.AllowDrop = true;
			this.MP1DimWaitComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.MP1DimWaitComboBox.FormattingEnabled = true;
			this.MP1DimWaitComboBox.Location = new System.Drawing.Point(152, 179);
			this.MP1DimWaitComboBox.Name = "MP1DimWaitComboBox";
			this.MP1DimWaitComboBox.Size = new System.Drawing.Size(92, 21);
			this.MP1DimWaitComboBox.TabIndex = 82;
			this.MP1DimWaitComboBox.SelectedIndexChanged += new System.EventHandler(this.MP1DimWaitComboBox_SelectedIndexChanged);
			// 
			// MP1DimWaitLabel
			// 
			this.MP1DimWaitLabel.AutoSize = true;
			this.MP1DimWaitLabel.Location = new System.Drawing.Point(5, 183);
			this.MP1DimWaitLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.MP1DimWaitLabel.Name = "MP1DimWaitLabel";
			this.MP1DimWaitLabel.Size = new System.Drawing.Size(118, 13);
			this.MP1DimWaitLabel.TabIndex = 81;
			this.MP1DimWaitLabel.Text = "Time Until Dim (MP = 1)";
			// 
			// dimWaitNotPresentAdLabel
			// 
			this.dimWaitNotPresentAdLabel.AutoSize = true;
			this.dimWaitNotPresentAdLabel.Location = new System.Drawing.Point(5, 134);
			this.dimWaitNotPresentAdLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.dimWaitNotPresentAdLabel.Name = "dimWaitNotPresentAdLabel";
			this.dimWaitNotPresentAdLabel.Size = new System.Drawing.Size(140, 13);
			this.dimWaitNotPresentAdLabel.TabIndex = 79;
			this.dimWaitNotPresentAdLabel.Text = "Time Until Dim (Not Present)";
			// 
			// adNotPresentDimWaitTimeComboBox
			// 
			this.adNotPresentDimWaitTimeComboBox.AllowDrop = true;
			this.adNotPresentDimWaitTimeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.adNotPresentDimWaitTimeComboBox.FormattingEnabled = true;
			this.adNotPresentDimWaitTimeComboBox.Location = new System.Drawing.Point(151, 131);
			this.adNotPresentDimWaitTimeComboBox.Name = "adNotPresentDimWaitTimeComboBox";
			this.adNotPresentDimWaitTimeComboBox.Size = new System.Drawing.Size(93, 21);
			this.adNotPresentDimWaitTimeComboBox.TabIndex = 80;
			this.adNotPresentDimWaitTimeComboBox.SelectedIndexChanged += new System.EventHandler(this.adNotPresentDimWaitTimeComboBox_SelectedIndexChanged);
			// 
			// mispredictionTimeLabel
			// 
			this.mispredictionTimeLabel.AutoSize = true;
			this.mispredictionTimeLabel.Location = new System.Drawing.Point(6, 109);
			this.mispredictionTimeLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.mispredictionTimeLabel.Name = "mispredictionTimeLabel";
			this.mispredictionTimeLabel.Size = new System.Drawing.Size(137, 13);
			this.mispredictionTimeLabel.TabIndex = 77;
			this.mispredictionTimeLabel.Text = "Misprediction Time Window";
			// 
			// mispredictionTimeWindowCombobox
			// 
			this.mispredictionTimeWindowCombobox.AllowDrop = true;
			this.mispredictionTimeWindowCombobox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.mispredictionTimeWindowCombobox.FormattingEnabled = true;
			this.mispredictionTimeWindowCombobox.Location = new System.Drawing.Point(161, 107);
			this.mispredictionTimeWindowCombobox.Name = "mispredictionTimeWindowCombobox";
			this.mispredictionTimeWindowCombobox.Size = new System.Drawing.Size(82, 21);
			this.mispredictionTimeWindowCombobox.TabIndex = 78;
			this.mispredictionTimeWindowCombobox.SelectedIndexChanged += new System.EventHandler(this.mispredictionTimeWindowCombobox_SelectedIndexChanged);
			// 
			// mispredictionWithFaceDetectionCheckbox
			// 
			this.mispredictionWithFaceDetectionCheckbox.AutoSize = true;
			this.mispredictionWithFaceDetectionCheckbox.Location = new System.Drawing.Point(226, 89);
			this.mispredictionWithFaceDetectionCheckbox.Name = "mispredictionWithFaceDetectionCheckbox";
			this.mispredictionWithFaceDetectionCheckbox.Size = new System.Drawing.Size(15, 14);
			this.mispredictionWithFaceDetectionCheckbox.TabIndex = 76;
			this.mispredictionWithFaceDetectionCheckbox.UseVisualStyleBackColor = true;
			this.mispredictionWithFaceDetectionCheckbox.CheckedChanged += new System.EventHandler(this.mispredictionWithFaceDetectionCheckbox_CheckedChanged);
			// 
			// mispredictionFaceDetectionLabel
			// 
			this.mispredictionFaceDetectionLabel.AutoSize = true;
			this.mispredictionFaceDetectionLabel.Location = new System.Drawing.Point(7, 89);
			this.mispredictionFaceDetectionLabel.Name = "mispredictionFaceDetectionLabel";
			this.mispredictionFaceDetectionLabel.Size = new System.Drawing.Size(170, 13);
			this.mispredictionFaceDetectionLabel.TabIndex = 75;
			this.mispredictionFaceDetectionLabel.Text = "Misprediction With Face Detection";
			// 
			// globalModeCheckbox
			// 
			this.globalModeCheckbox.AutoSize = true;
			this.globalModeCheckbox.Location = new System.Drawing.Point(107, 58);
			this.globalModeCheckbox.Name = "globalModeCheckbox";
			this.globalModeCheckbox.Size = new System.Drawing.Size(15, 14);
			this.globalModeCheckbox.TabIndex = 78;
			this.globalModeCheckbox.UseVisualStyleBackColor = true;
			this.globalModeCheckbox.CheckedChanged += new System.EventHandler(this.globalModeCheckbox_CheckedChanged);
			// 
			// globalModeLabel
			// 
			this.globalModeLabel.AutoSize = true;
			this.globalModeLabel.Location = new System.Drawing.Point(8, 59);
			this.globalModeLabel.Name = "globalModeLabel";
			this.globalModeLabel.Size = new System.Drawing.Size(67, 13);
			this.globalModeLabel.TabIndex = 77;
			this.globalModeLabel.Text = "Global Mode";
			// 
			// globalModePanel
			// 
			this.globalModePanel.Controls.Add(this.testModeCheckbox);
			this.globalModePanel.Controls.Add(this.testModeLabel);
			this.globalModePanel.Location = new System.Drawing.Point(9, 459);
			this.globalModePanel.Name = "globalModePanel";
			this.globalModePanel.Size = new System.Drawing.Size(173, 34);
			this.globalModePanel.TabIndex = 79;
			// 
			// testModeCheckbox
			// 
			this.testModeCheckbox.AutoSize = true;
			this.testModeCheckbox.Location = new System.Drawing.Point(91, 10);
			this.testModeCheckbox.Name = "testModeCheckbox";
			this.testModeCheckbox.Size = new System.Drawing.Size(15, 14);
			this.testModeCheckbox.TabIndex = 79;
			this.testModeCheckbox.UseVisualStyleBackColor = true;
			this.testModeCheckbox.CheckedChanged += new System.EventHandler(this.testModeCheckbox_CheckedChanged);
			// 
			// testModeLabel
			// 
			this.testModeLabel.AutoSize = true;
			this.testModeLabel.Location = new System.Drawing.Point(6, 10);
			this.testModeLabel.Name = "testModeLabel";
			this.testModeLabel.Size = new System.Drawing.Size(58, 13);
			this.testModeLabel.TabIndex = 79;
			this.testModeLabel.Text = "Test Mode";
			// 
			// presenceStatusPanel
			// 
			this.presenceStatusPanel.Controls.Add(this.SensorUserPresenceValueLabel);
			this.presenceStatusPanel.Controls.Add(this.PolicyUserPresenceValueLabel);
			this.presenceStatusPanel.Controls.Add(this.PlatformUserPresenceValueLabel);
			this.presenceStatusPanel.Controls.Add(this.SensorUserPresenceStatusLabel);
			this.presenceStatusPanel.Controls.Add(this.PolicyUserPresenceStatusLabel);
			this.presenceStatusPanel.Controls.Add(this.PlatformUserPresenceStatusLabel);
			this.presenceStatusPanel.Location = new System.Drawing.Point(188, 382);
			this.presenceStatusPanel.Name = "presenceStatusPanel";
			this.presenceStatusPanel.Size = new System.Drawing.Size(290, 79);
			this.presenceStatusPanel.TabIndex = 80;
			// 
			// SensorUserPresenceValueLabel
			// 
			this.SensorUserPresenceValueLabel.AutoSize = true;
			this.SensorUserPresenceValueLabel.Location = new System.Drawing.Point(190, 58);
			this.SensorUserPresenceValueLabel.Name = "SensorUserPresenceValueLabel";
			this.SensorUserPresenceValueLabel.Size = new System.Drawing.Size(49, 13);
			this.SensorUserPresenceValueLabel.TabIndex = 6;
			this.SensorUserPresenceValueLabel.Text = "INVALID";
			// 
			// PolicyUserPresenceValueLabel
			// 
			this.PolicyUserPresenceValueLabel.AutoSize = true;
			this.PolicyUserPresenceValueLabel.Location = new System.Drawing.Point(190, 35);
			this.PolicyUserPresenceValueLabel.Name = "PolicyUserPresenceValueLabel";
			this.PolicyUserPresenceValueLabel.Size = new System.Drawing.Size(49, 13);
			this.PolicyUserPresenceValueLabel.TabIndex = 5;
			this.PolicyUserPresenceValueLabel.Text = "INVALID";
			// 
			// PlatformUserPresenceValueLabel
			// 
			this.PlatformUserPresenceValueLabel.AutoSize = true;
			this.PlatformUserPresenceValueLabel.Location = new System.Drawing.Point(190, 11);
			this.PlatformUserPresenceValueLabel.Name = "PlatformUserPresenceValueLabel";
			this.PlatformUserPresenceValueLabel.Size = new System.Drawing.Size(49, 13);
			this.PlatformUserPresenceValueLabel.TabIndex = 4;
			this.PlatformUserPresenceValueLabel.Text = "INVALID";
			// 
			// SensorUserPresenceStatusLabel
			// 
			this.SensorUserPresenceStatusLabel.AutoSize = true;
			this.SensorUserPresenceStatusLabel.Location = new System.Drawing.Point(9, 58);
			this.SensorUserPresenceStatusLabel.Name = "SensorUserPresenceStatusLabel";
			this.SensorUserPresenceStatusLabel.Size = new System.Drawing.Size(146, 13);
			this.SensorUserPresenceStatusLabel.TabIndex = 2;
			this.SensorUserPresenceStatusLabel.Text = "Sensor User Presence Status";
			// 
			// PolicyUserPresenceStatusLabel
			// 
			this.PolicyUserPresenceStatusLabel.AutoSize = true;
			this.PolicyUserPresenceStatusLabel.Location = new System.Drawing.Point(9, 35);
			this.PolicyUserPresenceStatusLabel.Name = "PolicyUserPresenceStatusLabel";
			this.PolicyUserPresenceStatusLabel.Size = new System.Drawing.Size(141, 13);
			this.PolicyUserPresenceStatusLabel.TabIndex = 1;
			this.PolicyUserPresenceStatusLabel.Text = "Policy User Presence Status";
			// 
			// PlatformUserPresenceStatusLabel
			// 
			this.PlatformUserPresenceStatusLabel.AutoSize = true;
			this.PlatformUserPresenceStatusLabel.Location = new System.Drawing.Point(9, 11);
			this.PlatformUserPresenceStatusLabel.Name = "PlatformUserPresenceStatusLabel";
			this.PlatformUserPresenceStatusLabel.Size = new System.Drawing.Size(151, 13);
			this.PlatformUserPresenceStatusLabel.TabIndex = 0;
			this.PlatformUserPresenceStatusLabel.Text = "Platform User Presence Status";
			// 
			// privacyPanel
			// 
			this.privacyPanel.Controls.Add(this.privacyCheckbox);
			this.privacyPanel.Controls.Add(this.privacyLabel);
			this.privacyPanel.Location = new System.Drawing.Point(943, 382);
			this.privacyPanel.Name = "privacyPanel";
			this.privacyPanel.Size = new System.Drawing.Size(137, 30);
			this.privacyPanel.TabIndex = 81;
			// 
			// privacyCheckbox
			// 
			this.privacyCheckbox.AutoSize = true;
			this.privacyCheckbox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.privacyCheckbox.Location = new System.Drawing.Point(106, 9);
			this.privacyCheckbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.privacyCheckbox.Name = "privacyCheckbox";
			this.privacyCheckbox.Size = new System.Drawing.Size(15, 14);
			this.privacyCheckbox.TabIndex = 1;
			this.privacyCheckbox.UseVisualStyleBackColor = true;
			this.privacyCheckbox.CheckedChanged += new System.EventHandler(this.privacyCheckBox_CheckedChanged);
			// 
			// privacyLabel
			// 
			this.privacyLabel.AutoSize = true;
			this.privacyLabel.Location = new System.Drawing.Point(14, 9);
			this.privacyLabel.Name = "privacyLabel";
			this.privacyLabel.Size = new System.Drawing.Size(84, 13);
			this.privacyLabel.TabIndex = 0;
			this.privacyLabel.Text = "Privacy Enabled";
			// 
			// appFeaturesPanel
			// 
			this.appFeaturesPanel.Controls.Add(this.enabledEventsLabel);
			this.appFeaturesPanel.Controls.Add(this.enabledEventsListBox);
			this.appFeaturesPanel.Controls.Add(this.globalModeCheckbox);
			this.appFeaturesPanel.Controls.Add(this.globalModeLabel);
			this.appFeaturesPanel.Controls.Add(this.monitorAppCheckbox);
			this.appFeaturesPanel.Controls.Add(this.monitorAppLabel);
			this.appFeaturesPanel.Controls.Add(this.appNameComboBox);
			this.appFeaturesPanel.Controls.Add(this.appNameLabel);
			this.appFeaturesPanel.Location = new System.Drawing.Point(485, 384);
			this.appFeaturesPanel.Name = "appFeaturesPanel";
			this.appFeaturesPanel.Size = new System.Drawing.Size(452, 77);
			this.appFeaturesPanel.TabIndex = 82;
			// 
			// enabledEventsLabel
			// 
			this.enabledEventsLabel.AutoSize = true;
			this.enabledEventsLabel.Location = new System.Drawing.Point(203, 35);
			this.enabledEventsLabel.Name = "enabledEventsLabel";
			this.enabledEventsLabel.Size = new System.Drawing.Size(96, 13);
			this.enabledEventsLabel.TabIndex = 99;
			this.enabledEventsLabel.Text = "Subscribed Events";
			// 
			// enabledEventsListBox
			// 
			this.enabledEventsListBox.FormattingEnabled = true;
			this.enabledEventsListBox.Location = new System.Drawing.Point(305, 6);
			this.enabledEventsListBox.Name = "enabledEventsListBox";
			this.enabledEventsListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
			this.enabledEventsListBox.Size = new System.Drawing.Size(138, 69);
			this.enabledEventsListBox.TabIndex = 98;
			this.enabledEventsListBox.SelectedIndexChanged += new System.EventHandler(this.enabledEventsListBox_SelectedIndexChanged);
			// 
			// monitorAppCheckbox
			// 
			this.monitorAppCheckbox.AutoSize = true;
			this.monitorAppCheckbox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.monitorAppCheckbox.Location = new System.Drawing.Point(107, 36);
			this.monitorAppCheckbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.monitorAppCheckbox.Name = "monitorAppCheckbox";
			this.monitorAppCheckbox.Size = new System.Drawing.Size(15, 14);
			this.monitorAppCheckbox.TabIndex = 3;
			this.monitorAppCheckbox.UseVisualStyleBackColor = true;
			this.monitorAppCheckbox.CheckedChanged += new System.EventHandler(this.monitorAppCheckbox_CheckedChanged);
			// 
			// monitorAppLabel
			// 
			this.monitorAppLabel.AutoSize = true;
			this.monitorAppLabel.Location = new System.Drawing.Point(9, 36);
			this.monitorAppLabel.Name = "monitorAppLabel";
			this.monitorAppLabel.Size = new System.Drawing.Size(64, 13);
			this.monitorAppLabel.TabIndex = 2;
			this.monitorAppLabel.Text = "Monitor App";
			// 
			// appNameComboBox
			// 
			this.appNameComboBox.AllowDrop = true;
			this.appNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.appNameComboBox.FormattingEnabled = true;
			this.appNameComboBox.Location = new System.Drawing.Point(72, 8);
			this.appNameComboBox.Name = "appNameComboBox";
			this.appNameComboBox.Size = new System.Drawing.Size(121, 21);
			this.appNameComboBox.TabIndex = 1;
			this.appNameComboBox.SelectedIndexChanged += new System.EventHandler(this.appNameComboBox_SelectedIndexChanged);
			// 
			// appNameLabel
			// 
			this.appNameLabel.AutoSize = true;
			this.appNameLabel.Location = new System.Drawing.Point(9, 12);
			this.appNameLabel.Name = "appNameLabel";
			this.appNameLabel.Size = new System.Drawing.Size(57, 13);
			this.appNameLabel.TabIndex = 0;
			this.appNameLabel.Text = "App Name";
			// 
			// onlookerDetectionPanel
			// 
			this.onlookerDetectionPanel.Controls.Add(this.onlookerDetectionCheckBox);
			this.onlookerDetectionPanel.Controls.Add(this.onlookerDetectionLabel);
			this.onlookerDetectionPanel.Location = new System.Drawing.Point(796, 9);
			this.onlookerDetectionPanel.Name = "onlookerDetectionPanel";
			this.onlookerDetectionPanel.Size = new System.Drawing.Size(278, 23);
			this.onlookerDetectionPanel.TabIndex = 58;
			// 
			// onlookerDetectionCheckBox
			// 
			this.onlookerDetectionCheckBox.AutoSize = true;
			this.onlookerDetectionCheckBox.Location = new System.Drawing.Point(251, 4);
			this.onlookerDetectionCheckBox.Name = "onlookerDetectionCheckBox";
			this.onlookerDetectionCheckBox.Size = new System.Drawing.Size(15, 14);
			this.onlookerDetectionCheckBox.TabIndex = 55;
			this.onlookerDetectionCheckBox.UseVisualStyleBackColor = true;
			this.onlookerDetectionCheckBox.CheckedChanged += new System.EventHandler(this.onlookerDetectionCheckBox_CheckedChanged);
			this.onlookerDetectionCheckBox.EnabledChanged += new System.EventHandler(this.onlookerDetectionCheckBox_EnabledChanged);
			// 
			// onlookerDetectionLabel
			// 
			this.onlookerDetectionLabel.AutoSize = true;
			this.onlookerDetectionLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.onlookerDetectionLabel.Location = new System.Drawing.Point(6, 4);
			this.onlookerDetectionLabel.Name = "onlookerDetectionLabel";
			this.onlookerDetectionLabel.Size = new System.Drawing.Size(126, 14);
			this.onlookerDetectionLabel.TabIndex = 54;
			this.onlookerDetectionLabel.Text = "Onlooker Detection";
			// 
			// onlookerDetectionSettingsPanel
			// 
			this.onlookerDetectionSettingsPanel.Controls.Add(this.odCancelSnoozeButton);
			this.onlookerDetectionSettingsPanel.Controls.Add(this.onlookerDetectionEnableOnLowBatteryPanel);
			this.onlookerDetectionSettingsPanel.Controls.Add(this.onlookerDetectionDimWhenOnlookerDetectedPanel);
			this.onlookerDetectionSettingsPanel.Controls.Add(this.onlookerDetectionAbsenceIntervalComboBox);
			this.onlookerDetectionSettingsPanel.Controls.Add(this.onlookerDetectionAbsenceWaitTimeLabel);
			this.onlookerDetectionSettingsPanel.Controls.Add(this.onlookerDetectionEnableWithExternalMonitorPanel);
			this.onlookerDetectionSettingsPanel.Controls.Add(this.onlookerDetectionDimTargetLabel);
			this.onlookerDetectionSettingsPanel.Controls.Add(this.onlookerDetectionDimTargetComboBox);
			this.onlookerDetectionSettingsPanel.Controls.Add(this.onlookerDetectionDimmingTimeLabel);
			this.onlookerDetectionSettingsPanel.Controls.Add(this.onlookerDetectionDimmingTimeComboBox);
			this.onlookerDetectionSettingsPanel.Controls.Add(this.onlookerDetectionLowBatteryLimitComboBox);
			this.onlookerDetectionSettingsPanel.Controls.Add(this.onlookerDetectionLowBatteryLimitLabel);
			this.onlookerDetectionSettingsPanel.Controls.Add(this.onlookerDetectionDelayIntervalComboBox);
			this.onlookerDetectionSettingsPanel.Controls.Add(this.onlookerDetectionDelayIntervalLabel);
			this.onlookerDetectionSettingsPanel.Location = new System.Drawing.Point(801, 40);
			this.onlookerDetectionSettingsPanel.Name = "onlookerDetectionSettingsPanel";
			this.onlookerDetectionSettingsPanel.Size = new System.Drawing.Size(259, 253);
			this.onlookerDetectionSettingsPanel.TabIndex = 97;
			// 
			// odCancelSnoozeButton
			// 
			this.odCancelSnoozeButton.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.odCancelSnoozeButton.Enabled = false;
			this.odCancelSnoozeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.odCancelSnoozeButton.Location = new System.Drawing.Point(5, 211);
			this.odCancelSnoozeButton.Name = "odCancelSnoozeButton";
			this.odCancelSnoozeButton.Size = new System.Drawing.Size(247, 28);
			this.odCancelSnoozeButton.TabIndex = 100;
			this.odCancelSnoozeButton.Text = "Cancel Onlooker Detection Snooze";
			this.odCancelSnoozeButton.UseVisualStyleBackColor = true;
			this.odCancelSnoozeButton.Click += new System.EventHandler(this.odCancelSnoozeButton_Click);
			// 
			// onlookerDetectionEnableOnLowBatteryPanel
			// 
			this.onlookerDetectionEnableOnLowBatteryPanel.Controls.Add(this.onlookerDetectionEnableOnLowBatteryOffRadioButton);
			this.onlookerDetectionEnableOnLowBatteryPanel.Controls.Add(this.onlookerDetectionEnableOnLowBatteryOnRadioButton);
			this.onlookerDetectionEnableOnLowBatteryPanel.Controls.Add(this.onlookerDetectionEnableOnLowBatteryLabel);
			this.onlookerDetectionEnableOnLowBatteryPanel.Location = new System.Drawing.Point(3, 134);
			this.onlookerDetectionEnableOnLowBatteryPanel.Name = "onlookerDetectionEnableOnLowBatteryPanel";
			this.onlookerDetectionEnableOnLowBatteryPanel.Size = new System.Drawing.Size(248, 22);
			this.onlookerDetectionEnableOnLowBatteryPanel.TabIndex = 94;
			// 
			// onlookerDetectionEnableOnLowBatteryOffRadioButton
			// 
			this.onlookerDetectionEnableOnLowBatteryOffRadioButton.AutoSize = true;
			this.onlookerDetectionEnableOnLowBatteryOffRadioButton.Location = new System.Drawing.Point(200, 3);
			this.onlookerDetectionEnableOnLowBatteryOffRadioButton.Name = "onlookerDetectionEnableOnLowBatteryOffRadioButton";
			this.onlookerDetectionEnableOnLowBatteryOffRadioButton.Size = new System.Drawing.Size(50, 17);
			this.onlookerDetectionEnableOnLowBatteryOffRadioButton.TabIndex = 76;
			this.onlookerDetectionEnableOnLowBatteryOffRadioButton.TabStop = true;
			this.onlookerDetectionEnableOnLowBatteryOffRadioButton.Text = "False";
			this.onlookerDetectionEnableOnLowBatteryOffRadioButton.UseVisualStyleBackColor = true;
			this.onlookerDetectionEnableOnLowBatteryOffRadioButton.CheckedChanged += new System.EventHandler(this.onlookerDetectionEnableOnLowBatteryOffRadioButton_CheckedChanged);
			// 
			// onlookerDetectionEnableOnLowBatteryOnRadioButton
			// 
			this.onlookerDetectionEnableOnLowBatteryOnRadioButton.AutoSize = true;
			this.onlookerDetectionEnableOnLowBatteryOnRadioButton.Checked = true;
			this.onlookerDetectionEnableOnLowBatteryOnRadioButton.Location = new System.Drawing.Point(155, 3);
			this.onlookerDetectionEnableOnLowBatteryOnRadioButton.Name = "onlookerDetectionEnableOnLowBatteryOnRadioButton";
			this.onlookerDetectionEnableOnLowBatteryOnRadioButton.Size = new System.Drawing.Size(47, 17);
			this.onlookerDetectionEnableOnLowBatteryOnRadioButton.TabIndex = 75;
			this.onlookerDetectionEnableOnLowBatteryOnRadioButton.TabStop = true;
			this.onlookerDetectionEnableOnLowBatteryOnRadioButton.Text = "True";
			this.onlookerDetectionEnableOnLowBatteryOnRadioButton.UseVisualStyleBackColor = true;
			this.onlookerDetectionEnableOnLowBatteryOnRadioButton.CheckedChanged += new System.EventHandler(this.onlookerDetectionEnableOnLowBatteryOnRadioButton_CheckedChanged);
			// 
			// onlookerDetectionEnableOnLowBatteryLabel
			// 
			this.onlookerDetectionEnableOnLowBatteryLabel.AutoSize = true;
			this.onlookerDetectionEnableOnLowBatteryLabel.Location = new System.Drawing.Point(5, 6);
			this.onlookerDetectionEnableOnLowBatteryLabel.Name = "onlookerDetectionEnableOnLowBatteryLabel";
			this.onlookerDetectionEnableOnLowBatteryLabel.Size = new System.Drawing.Size(116, 13);
			this.onlookerDetectionEnableOnLowBatteryLabel.TabIndex = 77;
			this.onlookerDetectionEnableOnLowBatteryLabel.Text = "Enable On Low Battery";
			// 
			// onlookerDetectionDimWhenOnlookerDetectedPanel
			// 
			this.onlookerDetectionDimWhenOnlookerDetectedPanel.Controls.Add(this.onlookerDetectionDimWhenDetectedOffRadioButton);
			this.onlookerDetectionDimWhenOnlookerDetectedPanel.Controls.Add(this.onlookerDetectionDimWhenDetectedOnRadioButton);
			this.onlookerDetectionDimWhenOnlookerDetectedPanel.Controls.Add(this.onlookerDetectionDimWhenDetectedLabel);
			this.onlookerDetectionDimWhenOnlookerDetectedPanel.Location = new System.Drawing.Point(3, 56);
			this.onlookerDetectionDimWhenOnlookerDetectedPanel.Name = "onlookerDetectionDimWhenOnlookerDetectedPanel";
			this.onlookerDetectionDimWhenOnlookerDetectedPanel.Size = new System.Drawing.Size(248, 22);
			this.onlookerDetectionDimWhenOnlookerDetectedPanel.TabIndex = 93;
			// 
			// onlookerDetectionDimWhenDetectedOffRadioButton
			// 
			this.onlookerDetectionDimWhenDetectedOffRadioButton.AutoSize = true;
			this.onlookerDetectionDimWhenDetectedOffRadioButton.Location = new System.Drawing.Point(214, 3);
			this.onlookerDetectionDimWhenDetectedOffRadioButton.Name = "onlookerDetectionDimWhenDetectedOffRadioButton";
			this.onlookerDetectionDimWhenDetectedOffRadioButton.Size = new System.Drawing.Size(39, 17);
			this.onlookerDetectionDimWhenDetectedOffRadioButton.TabIndex = 76;
			this.onlookerDetectionDimWhenDetectedOffRadioButton.TabStop = true;
			this.onlookerDetectionDimWhenDetectedOffRadioButton.Text = "Off";
			this.onlookerDetectionDimWhenDetectedOffRadioButton.UseVisualStyleBackColor = true;
			this.onlookerDetectionDimWhenDetectedOffRadioButton.CheckedChanged += new System.EventHandler(this.onlookerDetectionDimWhenDetectedOffRadioButton_CheckedChanged);
			// 
			// onlookerDetectionDimWhenDetectedOnRadioButton
			// 
			this.onlookerDetectionDimWhenDetectedOnRadioButton.AutoSize = true;
			this.onlookerDetectionDimWhenDetectedOnRadioButton.Checked = true;
			this.onlookerDetectionDimWhenDetectedOnRadioButton.Location = new System.Drawing.Point(169, 3);
			this.onlookerDetectionDimWhenDetectedOnRadioButton.Name = "onlookerDetectionDimWhenDetectedOnRadioButton";
			this.onlookerDetectionDimWhenDetectedOnRadioButton.Size = new System.Drawing.Size(39, 17);
			this.onlookerDetectionDimWhenDetectedOnRadioButton.TabIndex = 75;
			this.onlookerDetectionDimWhenDetectedOnRadioButton.TabStop = true;
			this.onlookerDetectionDimWhenDetectedOnRadioButton.Text = "On";
			this.onlookerDetectionDimWhenDetectedOnRadioButton.UseVisualStyleBackColor = true;
			this.onlookerDetectionDimWhenDetectedOnRadioButton.CheckedChanged += new System.EventHandler(this.onlookerDetectionDimWhenDetectedOnRadioButton_CheckedChanged);
			// 
			// onlookerDetectionDimWhenDetectedLabel
			// 
			this.onlookerDetectionDimWhenDetectedLabel.AutoSize = true;
			this.onlookerDetectionDimWhenDetectedLabel.Location = new System.Drawing.Point(5, 5);
			this.onlookerDetectionDimWhenDetectedLabel.Name = "onlookerDetectionDimWhenDetectedLabel";
			this.onlookerDetectionDimWhenDetectedLabel.Size = new System.Drawing.Size(150, 13);
			this.onlookerDetectionDimWhenDetectedLabel.TabIndex = 77;
			this.onlookerDetectionDimWhenDetectedLabel.Text = "Dim When Onlooker Detected";
			// 
			// onlookerDetectionAbsenceIntervalComboBox
			// 
			this.onlookerDetectionAbsenceIntervalComboBox.AllowDrop = true;
			this.onlookerDetectionAbsenceIntervalComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.onlookerDetectionAbsenceIntervalComboBox.FormattingEnabled = true;
			this.onlookerDetectionAbsenceIntervalComboBox.Location = new System.Drawing.Point(161, 181);
			this.onlookerDetectionAbsenceIntervalComboBox.Name = "onlookerDetectionAbsenceIntervalComboBox";
			this.onlookerDetectionAbsenceIntervalComboBox.Size = new System.Drawing.Size(92, 21);
			this.onlookerDetectionAbsenceIntervalComboBox.TabIndex = 92;
			this.onlookerDetectionAbsenceIntervalComboBox.SelectedIndexChanged += new System.EventHandler(this.onlookerDetectionAbsenceIntervalComboBox_SelectedIndexChanged);
			// 
			// onlookerDetectionAbsenceWaitTimeLabel
			// 
			this.onlookerDetectionAbsenceWaitTimeLabel.AutoSize = true;
			this.onlookerDetectionAbsenceWaitTimeLabel.Location = new System.Drawing.Point(5, 184);
			this.onlookerDetectionAbsenceWaitTimeLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.onlookerDetectionAbsenceWaitTimeLabel.Name = "onlookerDetectionAbsenceWaitTimeLabel";
			this.onlookerDetectionAbsenceWaitTimeLabel.Size = new System.Drawing.Size(146, 13);
			this.onlookerDetectionAbsenceWaitTimeLabel.TabIndex = 91;
			this.onlookerDetectionAbsenceWaitTimeLabel.Text = "Onlooker Absence Wait Time";
			// 
			// onlookerDetectionEnableWithExternalMonitorPanel
			// 
			this.onlookerDetectionEnableWithExternalMonitorPanel.Controls.Add(this.onlookerDetectionExternalMonitorOffRadioButton);
			this.onlookerDetectionEnableWithExternalMonitorPanel.Controls.Add(this.onlookerDetectionExternalMonitorOnRadioButton);
			this.onlookerDetectionEnableWithExternalMonitorPanel.Controls.Add(this.onlookerDetectionExternalMonitorLabel);
			this.onlookerDetectionEnableWithExternalMonitorPanel.Location = new System.Drawing.Point(4, 3);
			this.onlookerDetectionEnableWithExternalMonitorPanel.Name = "onlookerDetectionEnableWithExternalMonitorPanel";
			this.onlookerDetectionEnableWithExternalMonitorPanel.Size = new System.Drawing.Size(248, 22);
			this.onlookerDetectionEnableWithExternalMonitorPanel.TabIndex = 82;
			// 
			// onlookerDetectionExternalMonitorOffRadioButton
			// 
			this.onlookerDetectionExternalMonitorOffRadioButton.AutoSize = true;
			this.onlookerDetectionExternalMonitorOffRadioButton.Location = new System.Drawing.Point(214, 3);
			this.onlookerDetectionExternalMonitorOffRadioButton.Name = "onlookerDetectionExternalMonitorOffRadioButton";
			this.onlookerDetectionExternalMonitorOffRadioButton.Size = new System.Drawing.Size(39, 17);
			this.onlookerDetectionExternalMonitorOffRadioButton.TabIndex = 76;
			this.onlookerDetectionExternalMonitorOffRadioButton.TabStop = true;
			this.onlookerDetectionExternalMonitorOffRadioButton.Text = "Off";
			this.onlookerDetectionExternalMonitorOffRadioButton.UseVisualStyleBackColor = true;
			this.onlookerDetectionExternalMonitorOffRadioButton.CheckedChanged += new System.EventHandler(this.onlookerDetectionExternalMonitorOffRadioButton_CheckedChanged);
			// 
			// onlookerDetectionExternalMonitorOnRadioButton
			// 
			this.onlookerDetectionExternalMonitorOnRadioButton.AutoSize = true;
			this.onlookerDetectionExternalMonitorOnRadioButton.Checked = true;
			this.onlookerDetectionExternalMonitorOnRadioButton.Location = new System.Drawing.Point(169, 3);
			this.onlookerDetectionExternalMonitorOnRadioButton.Name = "onlookerDetectionExternalMonitorOnRadioButton";
			this.onlookerDetectionExternalMonitorOnRadioButton.Size = new System.Drawing.Size(39, 17);
			this.onlookerDetectionExternalMonitorOnRadioButton.TabIndex = 75;
			this.onlookerDetectionExternalMonitorOnRadioButton.TabStop = true;
			this.onlookerDetectionExternalMonitorOnRadioButton.Text = "On";
			this.onlookerDetectionExternalMonitorOnRadioButton.UseVisualStyleBackColor = true;
			this.onlookerDetectionExternalMonitorOnRadioButton.CheckedChanged += new System.EventHandler(this.onlookerDetectionExternalMonitorOnRadioButton_CheckedChanged);
			// 
			// onlookerDetectionExternalMonitorLabel
			// 
			this.onlookerDetectionExternalMonitorLabel.AutoSize = true;
			this.onlookerDetectionExternalMonitorLabel.Location = new System.Drawing.Point(5, 5);
			this.onlookerDetectionExternalMonitorLabel.Name = "onlookerDetectionExternalMonitorLabel";
			this.onlookerDetectionExternalMonitorLabel.Size = new System.Drawing.Size(144, 13);
			this.onlookerDetectionExternalMonitorLabel.TabIndex = 77;
			this.onlookerDetectionExternalMonitorLabel.Text = "Enable With External Monitor";
			// 
			// onlookerDetectionDimTargetLabel
			// 
			this.onlookerDetectionDimTargetLabel.AutoSize = true;
			this.onlookerDetectionDimTargetLabel.Location = new System.Drawing.Point(7, 114);
			this.onlookerDetectionDimTargetLabel.Name = "onlookerDetectionDimTargetLabel";
			this.onlookerDetectionDimTargetLabel.Size = new System.Drawing.Size(59, 13);
			this.onlookerDetectionDimTargetLabel.TabIndex = 88;
			this.onlookerDetectionDimTargetLabel.Text = "Dim Target";
			// 
			// onlookerDetectionDimTargetComboBox
			// 
			this.onlookerDetectionDimTargetComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.onlookerDetectionDimTargetComboBox.FormattingEnabled = true;
			this.onlookerDetectionDimTargetComboBox.Location = new System.Drawing.Point(178, 110);
			this.onlookerDetectionDimTargetComboBox.Name = "onlookerDetectionDimTargetComboBox";
			this.onlookerDetectionDimTargetComboBox.Size = new System.Drawing.Size(75, 21);
			this.onlookerDetectionDimTargetComboBox.TabIndex = 87;
			this.onlookerDetectionDimTargetComboBox.SelectedIndexChanged += new System.EventHandler(this.onlookerDetectionDimTargetComboBox_SelectedIndexChanged);
			// 
			// onlookerDetectionDimmingTimeLabel
			// 
			this.onlookerDetectionDimmingTimeLabel.AutoSize = true;
			this.onlookerDetectionDimmingTimeLabel.Location = new System.Drawing.Point(7, 86);
			this.onlookerDetectionDimmingTimeLabel.Name = "onlookerDetectionDimmingTimeLabel";
			this.onlookerDetectionDimmingTimeLabel.Size = new System.Drawing.Size(73, 13);
			this.onlookerDetectionDimmingTimeLabel.TabIndex = 86;
			this.onlookerDetectionDimmingTimeLabel.Text = "Dimming Time";
			// 
			// onlookerDetectionDimmingTimeComboBox
			// 
			this.onlookerDetectionDimmingTimeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.onlookerDetectionDimmingTimeComboBox.FormattingEnabled = true;
			this.onlookerDetectionDimmingTimeComboBox.Location = new System.Drawing.Point(178, 83);
			this.onlookerDetectionDimmingTimeComboBox.Name = "onlookerDetectionDimmingTimeComboBox";
			this.onlookerDetectionDimmingTimeComboBox.Size = new System.Drawing.Size(75, 21);
			this.onlookerDetectionDimmingTimeComboBox.TabIndex = 85;
			this.onlookerDetectionDimmingTimeComboBox.SelectedIndexChanged += new System.EventHandler(this.onlookerDetectionDimmingTimeComboBox_SelectedIndexChanged);
			// 
			// onlookerDetectionLowBatteryLimitComboBox
			// 
			this.onlookerDetectionLowBatteryLimitComboBox.AllowDrop = true;
			this.onlookerDetectionLowBatteryLimitComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.onlookerDetectionLowBatteryLimitComboBox.FormattingEnabled = true;
			this.onlookerDetectionLowBatteryLimitComboBox.Location = new System.Drawing.Point(161, 157);
			this.onlookerDetectionLowBatteryLimitComboBox.Name = "onlookerDetectionLowBatteryLimitComboBox";
			this.onlookerDetectionLowBatteryLimitComboBox.Size = new System.Drawing.Size(92, 21);
			this.onlookerDetectionLowBatteryLimitComboBox.TabIndex = 84;
			this.onlookerDetectionLowBatteryLimitComboBox.SelectedIndexChanged += new System.EventHandler(this.onlookerDetectionLowBatteryLimitComboBox_SelectedIndexChanged);
			// 
			// onlookerDetectionLowBatteryLimitLabel
			// 
			this.onlookerDetectionLowBatteryLimitLabel.AutoSize = true;
			this.onlookerDetectionLowBatteryLimitLabel.Location = new System.Drawing.Point(5, 161);
			this.onlookerDetectionLowBatteryLimitLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.onlookerDetectionLowBatteryLimitLabel.Name = "onlookerDetectionLowBatteryLimitLabel";
			this.onlookerDetectionLowBatteryLimitLabel.Size = new System.Drawing.Size(87, 13);
			this.onlookerDetectionLowBatteryLimitLabel.TabIndex = 83;
			this.onlookerDetectionLowBatteryLimitLabel.Text = "Low Battery Limit";
			// 
			// onlookerDetectionDelayIntervalComboBox
			// 
			this.onlookerDetectionDelayIntervalComboBox.AllowDrop = true;
			this.onlookerDetectionDelayIntervalComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.onlookerDetectionDelayIntervalComboBox.FormattingEnabled = true;
			this.onlookerDetectionDelayIntervalComboBox.Location = new System.Drawing.Point(161, 30);
			this.onlookerDetectionDelayIntervalComboBox.Name = "onlookerDetectionDelayIntervalComboBox";
			this.onlookerDetectionDelayIntervalComboBox.Size = new System.Drawing.Size(92, 21);
			this.onlookerDetectionDelayIntervalComboBox.TabIndex = 82;
			this.onlookerDetectionDelayIntervalComboBox.SelectedIndexChanged += new System.EventHandler(this.onlookerDetectionDelayIntervalComboBox_SelectedIndexChanged);
			// 
			// onlookerDetectionDelayIntervalLabel
			// 
			this.onlookerDetectionDelayIntervalLabel.AutoSize = true;
			this.onlookerDetectionDelayIntervalLabel.Location = new System.Drawing.Point(5, 34);
			this.onlookerDetectionDelayIntervalLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.onlookerDetectionDelayIntervalLabel.Name = "onlookerDetectionDelayIntervalLabel";
			this.onlookerDetectionDelayIntervalLabel.Size = new System.Drawing.Size(121, 13);
			this.onlookerDetectionDelayIntervalLabel.TabIndex = 81;
			this.onlookerDetectionDelayIntervalLabel.Text = "Detection Delay Interval";
			// 
			// icstSampleAppVersionLabel
			// 
			this.icstSampleAppVersionLabel.AutoSize = true;
			this.icstSampleAppVersionLabel.Location = new System.Drawing.Point(188, 472);
			this.icstSampleAppVersionLabel.Name = "icstSampleAppVersionLabel";
			this.icstSampleAppVersionLabel.Size = new System.Drawing.Size(222, 13);
			this.icstSampleAppVersionLabel.TabIndex = 39;
			this.icstSampleAppVersionLabel.Text = "Intel(R) Context Sensing SampleApp Version: ";
			// 
			// extendedCapabilitiesPanel
			// 
			this.extendedCapabilitiesPanel.Controls.Add(this.panel12);
			this.extendedCapabilitiesPanel.Controls.Add(this.panel11);
			this.extendedCapabilitiesPanel.Controls.Add(this.extendedCapabilitiesLabel);
			this.extendedCapabilitiesPanel.Controls.Add(this.odSensorStatusPanel);
			this.extendedCapabilitiesPanel.Controls.Add(this.activeSensorTypePanel);
			this.extendedCapabilitiesPanel.Controls.Add(this.mispredictionCountPanel);
			this.extendedCapabilitiesPanel.Location = new System.Drawing.Point(8, 291);
			this.extendedCapabilitiesPanel.Name = "extendedCapabilitiesPanel";
			this.extendedCapabilitiesPanel.Size = new System.Drawing.Size(518, 74);
			this.extendedCapabilitiesPanel.TabIndex = 98;
			// 
			// panel12
			// 
			this.panel12.Controls.Add(this.biometricPresenceSensorStatusValueLabel);
			this.panel12.Controls.Add(this.biometricPresenceSensorStatusLabel);
			this.panel12.Location = new System.Drawing.Point(266, 48);
			this.panel12.Name = "panel12";
			this.panel12.Size = new System.Drawing.Size(244, 23);
			this.panel12.TabIndex = 4;
			// 
			// biometricPresenceSensorStatusValueLabel
			// 
			this.biometricPresenceSensorStatusValueLabel.AutoSize = true;
			this.biometricPresenceSensorStatusValueLabel.Location = new System.Drawing.Point(94, 7);
			this.biometricPresenceSensorStatusValueLabel.Name = "biometricPresenceSensorStatusValueLabel";
			this.biometricPresenceSensorStatusValueLabel.Size = new System.Drawing.Size(146, 13);
			this.biometricPresenceSensorStatusValueLabel.TabIndex = 1;
			this.biometricPresenceSensorStatusValueLabel.Text = "SENSOR_STATUS_ERROR";
			// 
			// biometricPresenceSensorStatusLabel
			// 
			this.biometricPresenceSensorStatusLabel.AutoSize = true;
			this.biometricPresenceSensorStatusLabel.Location = new System.Drawing.Point(1, 8);
			this.biometricPresenceSensorStatusLabel.Name = "biometricPresenceSensorStatusLabel";
			this.biometricPresenceSensorStatusLabel.Size = new System.Drawing.Size(90, 13);
			this.biometricPresenceSensorStatusLabel.TabIndex = 0;
			this.biometricPresenceSensorStatusLabel.Text = "BP Sensor Status";
			// 
			// panel11
			// 
			this.panel11.Controls.Add(this.correlationStatusValueLabel);
			this.panel11.Controls.Add(this.correlationStatusLabel);
			this.panel11.Location = new System.Drawing.Point(267, 25);
			this.panel11.Name = "panel11";
			this.panel11.Size = new System.Drawing.Size(233, 27);
			this.panel11.TabIndex = 3;
			// 
			// correlationStatusValueLabel
			// 
			this.correlationStatusValueLabel.AutoSize = true;
			this.correlationStatusValueLabel.Location = new System.Drawing.Point(161, 7);
			this.correlationStatusValueLabel.Name = "correlationStatusValueLabel";
			this.correlationStatusValueLabel.Size = new System.Drawing.Size(38, 13);
			this.correlationStatusValueLabel.TabIndex = 1;
			this.correlationStatusValueLabel.Text = "Invalid";
			// 
			// correlationStatusLabel
			// 
			this.correlationStatusLabel.AutoSize = true;
			this.correlationStatusLabel.Location = new System.Drawing.Point(1, 8);
			this.correlationStatusLabel.Name = "correlationStatusLabel";
			this.correlationStatusLabel.Size = new System.Drawing.Size(90, 13);
			this.correlationStatusLabel.TabIndex = 0;
			this.correlationStatusLabel.Text = "Correlation Status";
			// 
			// extendedCapabilitiesLabel
			// 
			this.extendedCapabilitiesLabel.AutoSize = true;
			this.extendedCapabilitiesLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.extendedCapabilitiesLabel.Location = new System.Drawing.Point(4, 3);
			this.extendedCapabilitiesLabel.Name = "extendedCapabilitiesLabel";
			this.extendedCapabilitiesLabel.Size = new System.Drawing.Size(194, 14);
			this.extendedCapabilitiesLabel.TabIndex = 4;
			this.extendedCapabilitiesLabel.Text = "Features Extended Capabilities";
			this.extendedCapabilitiesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// odSensorStatusPanel
			// 
			this.odSensorStatusPanel.Controls.Add(this.odSensorStatusVallabel);
			this.odSensorStatusPanel.Controls.Add(this.odSensorStatusLabel);
			this.odSensorStatusPanel.Location = new System.Drawing.Point(2, 22);
			this.odSensorStatusPanel.Name = "odSensorStatusPanel";
			this.odSensorStatusPanel.Size = new System.Drawing.Size(257, 26);
			this.odSensorStatusPanel.TabIndex = 3;
			// 
			// odSensorStatusVallabel
			// 
			this.odSensorStatusVallabel.AutoSize = true;
			this.odSensorStatusVallabel.Location = new System.Drawing.Point(162, 7);
			this.odSensorStatusVallabel.Name = "odSensorStatusVallabel";
			this.odSensorStatusVallabel.Size = new System.Drawing.Size(38, 13);
			this.odSensorStatusVallabel.TabIndex = 1;
			this.odSensorStatusVallabel.Text = "Invalid";
			// 
			// odSensorStatusLabel
			// 
			this.odSensorStatusLabel.AutoSize = true;
			this.odSensorStatusLabel.Location = new System.Drawing.Point(2, 8);
			this.odSensorStatusLabel.Name = "odSensorStatusLabel";
			this.odSensorStatusLabel.Size = new System.Drawing.Size(119, 13);
			this.odSensorStatusLabel.TabIndex = 0;
			this.odSensorStatusLabel.Text = "Onlooker Sensor Status";
			this.odSensorStatusLabel.UseMnemonic = false;
			// 
			// activeSensorTypePanel
			// 
			this.activeSensorTypePanel.Controls.Add(this.activeSensorTypeValLabel);
			this.activeSensorTypePanel.Controls.Add(this.activeSensorTypeLabel);
			this.activeSensorTypePanel.Location = new System.Drawing.Point(2, 46);
			this.activeSensorTypePanel.Name = "activeSensorTypePanel";
			this.activeSensorTypePanel.Size = new System.Drawing.Size(257, 27);
			this.activeSensorTypePanel.TabIndex = 2;
			// 
			// activeSensorTypeValLabel
			// 
			this.activeSensorTypeValLabel.AutoSize = true;
			this.activeSensorTypeValLabel.Location = new System.Drawing.Point(161, 7);
			this.activeSensorTypeValLabel.Name = "activeSensorTypeValLabel";
			this.activeSensorTypeValLabel.Size = new System.Drawing.Size(38, 13);
			this.activeSensorTypeValLabel.TabIndex = 1;
			this.activeSensorTypeValLabel.Text = "Invalid";
			// 
			// activeSensorTypeLabel
			// 
			this.activeSensorTypeLabel.AutoSize = true;
			this.activeSensorTypeLabel.Location = new System.Drawing.Point(1, 8);
			this.activeSensorTypeLabel.Name = "activeSensorTypeLabel";
			this.activeSensorTypeLabel.Size = new System.Drawing.Size(100, 13);
			this.activeSensorTypeLabel.TabIndex = 0;
			this.activeSensorTypeLabel.Text = "Active Sensor Type";
			// 
			// mispredictionCountPanel
			// 
			this.mispredictionCountPanel.Controls.Add(this.mispredictionCountValLabel);
			this.mispredictionCountPanel.Controls.Add(this.mispredictionCountLabel);
			this.mispredictionCountPanel.Location = new System.Drawing.Point(267, 3);
			this.mispredictionCountPanel.Name = "mispredictionCountPanel";
			this.mispredictionCountPanel.Size = new System.Drawing.Size(234, 23);
			this.mispredictionCountPanel.TabIndex = 1;
			// 
			// mispredictionCountValLabel
			// 
			this.mispredictionCountValLabel.AutoSize = true;
			this.mispredictionCountValLabel.Location = new System.Drawing.Point(166, 6);
			this.mispredictionCountValLabel.Name = "mispredictionCountValLabel";
			this.mispredictionCountValLabel.Size = new System.Drawing.Size(13, 13);
			this.mispredictionCountValLabel.TabIndex = 1;
			this.mispredictionCountValLabel.Text = "0";
			// 
			// mispredictionCountLabel
			// 
			this.mispredictionCountLabel.AutoSize = true;
			this.mispredictionCountLabel.Location = new System.Drawing.Point(3, 5);
			this.mispredictionCountLabel.Name = "mispredictionCountLabel";
			this.mispredictionCountLabel.Size = new System.Drawing.Size(100, 13);
			this.mispredictionCountLabel.TabIndex = 0;
			this.mispredictionCountLabel.Text = "Misprediction Count";
			// 
			// appEnabledPanel
			// 
			this.appEnabledPanel.Controls.Add(this.appEnabledCheckBox);
			this.appEnabledPanel.Location = new System.Drawing.Point(943, 427);
			this.appEnabledPanel.Name = "appEnabledPanel";
			this.appEnabledPanel.Size = new System.Drawing.Size(136, 31);
			this.appEnabledPanel.TabIndex = 99;
			// 
			// appEnabledCheckBox
			// 
			this.appEnabledCheckBox.AutoSize = true;
			this.appEnabledCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.appEnabledCheckBox.Enabled = false;
			this.appEnabledCheckBox.Location = new System.Drawing.Point(8, 7);
			this.appEnabledCheckBox.Name = "appEnabledCheckBox";
			this.appEnabledCheckBox.Size = new System.Drawing.Size(120, 17);
			this.appEnabledCheckBox.TabIndex = 1;
			this.appEnabledCheckBox.Text = "Application Enabled";
			this.appEnabledCheckBox.UseVisualStyleBackColor = true;
			// 
			// FormWALWOA
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.AutoSize = true;
			this.ClientSize = new System.Drawing.Size(1085, 497);
			this.Controls.Add(this.appEnabledPanel);
			this.Controls.Add(this.extendedCapabilitiesPanel);
			this.Controls.Add(this.icstSampleAppVersionLabel);
			this.Controls.Add(this.onlookerDetectionSettingsPanel);
			this.Controls.Add(this.onlookerDetectionPanel);
			this.Controls.Add(this.appFeaturesPanel);
			this.Controls.Add(this.privacyPanel);
			this.Controls.Add(this.presenceStatusPanel);
			this.Controls.Add(this.globalModePanel);
			this.Controls.Add(this.adPanel);
			this.Controls.Add(this.panelAd);
			this.Controls.Add(this.panelWal);
			this.Controls.Add(this.nlopPanel);
			this.Controls.Add(this.groupBoxTrigger);
			this.Controls.Add(this.panelNlop);
			this.Controls.Add(this.lineSeparator);
			this.Controls.Add(this.proximityDistancePanel);
			this.Controls.Add(this.woaPanel);
			this.Controls.Add(this.walPanel);
			this.Controls.Add(this.panelWoa);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(2);
			this.Name = "FormWALWOA";
			this.Text = "Intel(R) Context Sensing Sample App";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormWALWOA_FormClosing);
			this.Load += new System.EventHandler(this.FormWALWOA_Load);
			this.panelWoa.ResumeLayout(false);
			this.panelWoa.PerformLayout();
			this.panel6.ResumeLayout(false);
			this.panel6.PerformLayout();
			this.panel5.ResumeLayout(false);
			this.panel5.PerformLayout();
			this.walPanel.ResumeLayout(false);
			this.walPanel.PerformLayout();
			this.woaPanel.ResumeLayout(false);
			this.woaPanel.PerformLayout();
			this.proximityDistancePanel.ResumeLayout(false);
			this.proximityDistancePanel.PerformLayout();
			this.panelNlop.ResumeLayout(false);
			this.panelNlop.PerformLayout();
			this.panel8.ResumeLayout(false);
			this.panel8.PerformLayout();
			this.panel7.ResumeLayout(false);
			this.panel7.PerformLayout();
			this.groupBoxTrigger.ResumeLayout(false);
			this.nlopPanel.ResumeLayout(false);
			this.nlopPanel.PerformLayout();
			this.panelWal.ResumeLayout(false);
			this.panelWal.PerformLayout();
			this.panel4.ResumeLayout(false);
			this.panel4.PerformLayout();
			this.panel3.ResumeLayout(false);
			this.panel3.PerformLayout();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.dimScreenPanel.ResumeLayout(false);
			this.dimScreenPanel.PerformLayout();
			this.walExternalMonitorPanel.ResumeLayout(false);
			this.walExternalMonitorPanel.PerformLayout();
			this.adPanel.ResumeLayout(false);
			this.adPanel.PerformLayout();
			this.panelAd.ResumeLayout(false);
			this.panelAd.PerformLayout();
			this.panel10.ResumeLayout(false);
			this.panel10.PerformLayout();
			this.panel9.ResumeLayout(false);
			this.panel9.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.globalModePanel.ResumeLayout(false);
			this.globalModePanel.PerformLayout();
			this.presenceStatusPanel.ResumeLayout(false);
			this.presenceStatusPanel.PerformLayout();
			this.privacyPanel.ResumeLayout(false);
			this.privacyPanel.PerformLayout();
			this.appFeaturesPanel.ResumeLayout(false);
			this.appFeaturesPanel.PerformLayout();
			this.onlookerDetectionPanel.ResumeLayout(false);
			this.onlookerDetectionPanel.PerformLayout();
			this.onlookerDetectionSettingsPanel.ResumeLayout(false);
			this.onlookerDetectionSettingsPanel.PerformLayout();
			this.onlookerDetectionEnableOnLowBatteryPanel.ResumeLayout(false);
			this.onlookerDetectionEnableOnLowBatteryPanel.PerformLayout();
			this.onlookerDetectionDimWhenOnlookerDetectedPanel.ResumeLayout(false);
			this.onlookerDetectionDimWhenOnlookerDetectedPanel.PerformLayout();
			this.onlookerDetectionEnableWithExternalMonitorPanel.ResumeLayout(false);
			this.onlookerDetectionEnableWithExternalMonitorPanel.PerformLayout();
			this.extendedCapabilitiesPanel.ResumeLayout(false);
			this.extendedCapabilitiesPanel.PerformLayout();
			this.panel12.ResumeLayout(false);
			this.panel12.PerformLayout();
			this.panel11.ResumeLayout(false);
			this.panel11.PerformLayout();
			this.odSensorStatusPanel.ResumeLayout(false);
			this.odSensorStatusPanel.PerformLayout();
			this.activeSensorTypePanel.ResumeLayout(false);
			this.activeSensorTypePanel.PerformLayout();
			this.mispredictionCountPanel.ResumeLayout(false);
			this.mispredictionCountPanel.PerformLayout();
			this.appEnabledPanel.ResumeLayout(false);
			this.appEnabledPanel.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label walLabel;
		private System.Windows.Forms.Label woaLabel;
		internal System.Windows.Forms.CheckBox woaCheckBox;
		internal System.Windows.Forms.CheckBox walCheckBox;
		private System.Windows.Forms.Label preDimIntervalLabel;
		private System.Windows.Forms.ComboBox preDimIntervalComboBox;
		private System.Windows.Forms.Panel panelWoa;
		private System.Windows.Forms.Panel walPanel;
		private System.Windows.Forms.Panel woaPanel;
		internal System.Windows.Forms.Label proximityDistanceValueLabel;
		private System.Windows.Forms.Panel proximityDistancePanel;
		private System.Windows.Forms.Label proximityDistanceLabel;
		private System.Windows.Forms.Label lineSeparator;
		private System.Windows.Forms.ComboBox comboBoxWaitTimer;
		private System.Windows.Forms.Label nlopWaitTimerLabel;
		private System.Windows.Forms.Panel panelNlop;
		private System.Windows.Forms.GroupBox groupBoxTrigger;
		private System.Windows.Forms.Button buttonTiggerStop;
		private System.Windows.Forms.Button buttonTriggerStart;
		private System.Windows.Forms.ComboBox nlopBatteryRemainingComboBox;
		private System.Windows.Forms.Label nlopBatteryRemainingLabel;
		private System.Windows.Forms.Label lockAfterDimIntervalLabel;
		private System.Windows.Forms.ComboBox lockAfterDimIntervalComboBox;
		private System.Windows.Forms.Label userPresentWaitIntervalLabel;
		private System.Windows.Forms.ComboBox userPresentWaitIntervalComboBox;
		private System.Windows.Forms.ComboBox woaBatteryRemainingComboBox;
		private System.Windows.Forms.Label woaBatteryRemainingLabel;
		private System.Windows.Forms.Panel nlopPanel;
		internal System.Windows.Forms.CheckBox nlopCheckBox;
		private System.Windows.Forms.Label nlopLabel;
		private System.Windows.Forms.Label nlopFailSafeTimerLabel;
		private System.Windows.Forms.ComboBox nlopFailSafeTimeoutComboBox;
		private System.Windows.Forms.Label notPresentDimTargetLabel;
		private System.Windows.Forms.ComboBox notPresentDimTargetComboBox;
		private System.Windows.Forms.Panel panelWal;
		private System.Windows.Forms.Panel walExternalMonitorPanel;
		private System.Windows.Forms.Label walExternalMonitorLabel;
		private System.Windows.Forms.RadioButton walExternalMonitorOnRadioButton;
		private System.Windows.Forms.RadioButton walExternalMonitorOffRadioButton;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.RadioButton woaEnableOnBatteryFalseRadioButton;
		private System.Windows.Forms.RadioButton woaEnableOnBatteryTrueRadioButton;
		private System.Windows.Forms.Label woaEnableOnBatteryLabel;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.RadioButton woaExternalMonitorOffRadioButton;
		private System.Windows.Forms.RadioButton woaExternalMonitorOnRadioButton;
		private System.Windows.Forms.Label woaExternalMonitorLabel;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.RadioButton nlopEnableOnBatteryFalseRadioButton;
		private System.Windows.Forms.RadioButton nlopEnableOnBatteryTrueRadioButton;
		private System.Windows.Forms.Label nlopEnableOnBatteryLabel;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.RadioButton nlopExternalMonitorOffRadioButton;
		private System.Windows.Forms.RadioButton nlopExternalMonitorOnRadioButton;
		private System.Windows.Forms.Label nlopExternalMonitorLabel;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.RadioButton displayOffOnRadioButton;
		private System.Windows.Forms.RadioButton displayOffOffRadioButton;
		private System.Windows.Forms.Label displayOffAfterLockLabel;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.RadioButton honorUserInCallOnRadioButton;
		private System.Windows.Forms.RadioButton honorUserInCallOffRadioButton;
		private System.Windows.Forms.Label honorUserInCallLabel;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.RadioButton honorPowerRequestsOnRadioButton;
		private System.Windows.Forms.RadioButton honorPowerRequestsOffRadioButton;
		private System.Windows.Forms.Label honorPowerRequestsLabel;
		private System.Windows.Forms.Panel dimScreenPanel;
		private System.Windows.Forms.RadioButton dimScreenOnRadioButton;
		private System.Windows.Forms.RadioButton dimScreenOffRadioButton;
		private System.Windows.Forms.Label dimScreenLabel;
		private System.Windows.Forms.Panel adPanel;
		internal System.Windows.Forms.CheckBox adCheckBox;
		private System.Windows.Forms.Label adLabel;
		private System.Windows.Forms.Panel panelAd;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.RadioButton adExternalMonitorOffRadioButton;
		private System.Windows.Forms.RadioButton adExternalMonitorOnRadioButton;
		private System.Windows.Forms.Label adExternalMonitorLabel;
		private System.Windows.Forms.Label dimTargetLabel;
		private System.Windows.Forms.ComboBox adDimTargetComboBox;
		private System.Windows.Forms.ComboBox MP2DimWaitComboBox;
		private System.Windows.Forms.Label MP2DimWaitLabel;
		private System.Windows.Forms.ComboBox MP1DimWaitComboBox;
		private System.Windows.Forms.Label MP1DimWaitLabel;
		private System.Windows.Forms.Label dimWaitNotPresentAdLabel;
		private System.Windows.Forms.ComboBox adNotPresentDimWaitTimeComboBox;
		private System.Windows.Forms.Label mispredictionTimeLabel;
		private System.Windows.Forms.ComboBox mispredictionTimeWindowCombobox;
		internal System.Windows.Forms.CheckBox mispredictionWithFaceDetectionCheckbox;
		private System.Windows.Forms.Label mispredictionFaceDetectionLabel;
		private System.Windows.Forms.Label notPresentDimmingTimeLabel;
		private System.Windows.Forms.ComboBox notPresentDimmingTimeComboBox;
		private System.Windows.Forms.ComboBox MP4DimWaitComboBox;
		private System.Windows.Forms.Label MP4DimWaitLabel;
		private System.Windows.Forms.ComboBox MP3DimWaitComboBox;
		private System.Windows.Forms.Label MP3DimWaitLabel;
		internal System.Windows.Forms.CheckBox globalModeCheckbox;
		private System.Windows.Forms.Label globalModeLabel;
		private System.Windows.Forms.Panel globalModePanel;
		private System.Windows.Forms.Panel presenceStatusPanel;
		private System.Windows.Forms.Label SensorUserPresenceStatusLabel;
		private System.Windows.Forms.Label PolicyUserPresenceStatusLabel;
		private System.Windows.Forms.Label PlatformUserPresenceStatusLabel;
		private System.Windows.Forms.Label SensorUserPresenceValueLabel;
		private System.Windows.Forms.Label PolicyUserPresenceValueLabel;
		private System.Windows.Forms.Label PlatformUserPresenceValueLabel;
		private System.Windows.Forms.Panel privacyPanel;
		internal System.Windows.Forms.CheckBox privacyCheckbox;
		private System.Windows.Forms.Label privacyLabel;
		private System.Windows.Forms.Panel appFeaturesPanel;
		private System.Windows.Forms.Label appNameLabel;
		private System.Windows.Forms.ComboBox appNameComboBox;
		private System.Windows.Forms.Label dimWaitDisengagedAdLabel;
		private System.Windows.Forms.ComboBox adDisengagedDimWaitTimeComboBox;
		private System.Windows.Forms.Label dimmingIntervalLabel;
		private System.Windows.Forms.ComboBox adDimmingIntervalComboBox;
		private System.Windows.Forms.Panel onlookerDetectionPanel;
		internal System.Windows.Forms.CheckBox onlookerDetectionCheckBox;
		private System.Windows.Forms.Label onlookerDetectionLabel;
		private System.Windows.Forms.Panel onlookerDetectionSettingsPanel;
		private System.Windows.Forms.ComboBox onlookerDetectionAbsenceIntervalComboBox;
		private System.Windows.Forms.Label onlookerDetectionAbsenceWaitTimeLabel;
		private System.Windows.Forms.Panel onlookerDetectionEnableWithExternalMonitorPanel;
		private System.Windows.Forms.RadioButton onlookerDetectionExternalMonitorOffRadioButton;
		private System.Windows.Forms.RadioButton onlookerDetectionExternalMonitorOnRadioButton;
		private System.Windows.Forms.Label onlookerDetectionExternalMonitorLabel;
		private System.Windows.Forms.Label onlookerDetectionDimTargetLabel;
		private System.Windows.Forms.ComboBox onlookerDetectionDimTargetComboBox;
		private System.Windows.Forms.Label onlookerDetectionDimmingTimeLabel;
		private System.Windows.Forms.ComboBox onlookerDetectionDimmingTimeComboBox;
		private System.Windows.Forms.ComboBox onlookerDetectionLowBatteryLimitComboBox;
		private System.Windows.Forms.Label onlookerDetectionLowBatteryLimitLabel;
		private System.Windows.Forms.ComboBox onlookerDetectionDelayIntervalComboBox;
		private System.Windows.Forms.Label onlookerDetectionDelayIntervalLabel;
		private System.Windows.Forms.Panel onlookerDetectionEnableOnLowBatteryPanel;
		private System.Windows.Forms.RadioButton onlookerDetectionEnableOnLowBatteryOffRadioButton;
		private System.Windows.Forms.RadioButton onlookerDetectionEnableOnLowBatteryOnRadioButton;
		private System.Windows.Forms.Label onlookerDetectionEnableOnLowBatteryLabel;
		private System.Windows.Forms.Panel onlookerDetectionDimWhenOnlookerDetectedPanel;
		private System.Windows.Forms.RadioButton onlookerDetectionDimWhenDetectedOffRadioButton;
		private System.Windows.Forms.RadioButton onlookerDetectionDimWhenDetectedOnRadioButton;
		private System.Windows.Forms.Label onlookerDetectionDimWhenDetectedLabel;
		private System.Windows.Forms.Panel panel9;
		private System.Windows.Forms.RadioButton adHonorPowerRequestOffRadioButton;
		private System.Windows.Forms.RadioButton adHonorPowerRequestOnRadioButton;
		private System.Windows.Forms.Label label1;
		internal System.Windows.Forms.CheckBox testModeCheckbox;
		private System.Windows.Forms.Label testModeLabel;
		internal System.Windows.Forms.CheckBox monitorAppCheckbox;
		private System.Windows.Forms.Label monitorAppLabel;
		private System.Windows.Forms.ListBox enabledEventsListBox;
		private System.Windows.Forms.Label enabledEventsLabel;
		private System.Windows.Forms.Label icstSampleAppVersionLabel;
		private System.Windows.Forms.Panel extendedCapabilitiesPanel;
		private System.Windows.Forms.Panel activeSensorTypePanel;
		private System.Windows.Forms.Panel mispredictionCountPanel;
		private System.Windows.Forms.Label mispredictionCountLabel;
		private System.Windows.Forms.Label activeSensorTypeLabel;
		private System.Windows.Forms.Label extendedCapabilitiesLabel;
		private System.Windows.Forms.Panel odSensorStatusPanel;
		private System.Windows.Forms.Label odSensorStatusVallabel;
		private System.Windows.Forms.Label odSensorStatusLabel;
		private System.Windows.Forms.Label activeSensorTypeValLabel;
		private System.Windows.Forms.Label mispredictionCountValLabel;
		private System.Windows.Forms.Panel appEnabledPanel;
		private System.Windows.Forms.CheckBox appEnabledCheckBox;
		private System.Windows.Forms.Button odCancelSnoozeButton;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.RadioButton honorUserInCallADRadioButtonOn;
        private System.Windows.Forms.RadioButton honorUserInCallADRadioButtonOff;
        private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Panel panel11;
		private System.Windows.Forms.Label correlationStatusValueLabel;
		private System.Windows.Forms.Label correlationStatusLabel;
		private System.Windows.Forms.Panel panel12;
		private System.Windows.Forms.Label biometricPresenceSensorStatusValueLabel;
		private System.Windows.Forms.Label biometricPresenceSensorStatusLabel;
	}
}
